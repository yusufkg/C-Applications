﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _008_Classes
{
    // yeni bir class oluşturduğumuzda default olarak gelen template'a public eklemek için:
    // C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\IDE\ItemTemplates\CSharp\Code\1033\Class
    // klasörünü açıp Class.cs dosyasını edit'liyoruz
    public class PublicClassTemplate
    {
    }
}
