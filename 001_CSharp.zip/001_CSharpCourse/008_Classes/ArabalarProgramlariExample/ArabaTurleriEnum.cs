﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _008_Classes.ArabalarProgramlariExampleV5
{
    enum ArabaTurleriEnum
    {
        Binek = 1,
        Ticari = 2,
        Belirsiz = 3
    }
}
