﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _008_Classes.ArabalarProgramlariExampleV5
{
    class ProgramAyarlari
    {
        public string ProgramBasligi { get; set; } = "*** Araba Programı V5 ***";
    }
}
