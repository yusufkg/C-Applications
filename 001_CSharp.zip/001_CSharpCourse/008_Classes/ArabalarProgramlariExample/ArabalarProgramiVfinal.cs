﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _008_Classes.ArabalarProgramlariExample
{
    class ArabalarProgramiVfinal
    {
        // Tüm problemler çözüldü ve artık versiyon değişikliğini tek bir yerden yönetebiliyoruz.

        public void Calistir()
        {
            ArabalarProgramlariExampleV5.ArabalarProgramiV5 program = new ArabalarProgramlariExampleV5.ArabalarProgramiV5();
            program.Calistir();
        }
    }
}
