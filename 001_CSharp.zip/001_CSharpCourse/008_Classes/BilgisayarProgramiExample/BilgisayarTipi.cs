﻿namespace _008_Classes.BilgisayarProgramiExample
{
    enum BilgisayarTipi
    {
        Masaüstü,
        Dizüstü,
        Sunucu
    }
}
