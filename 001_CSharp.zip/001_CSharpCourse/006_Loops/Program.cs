﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _006_Loops.Extras;

namespace _006_Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            // veri kümesini iterate yani dolaşmak için loop kullanıyoruz

            #region For Loop

            // 1'den 10'a kadar olan sayılar:
            Console.WriteLine("Begin All");
            for (int i = 1; i <= 10; i++) // int i = 1: başlangıç, i <= 10: şart, i++: bir dönüş bittiğinde ne yapılacak
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("End All");

            // 1'den 20'ye kadar olan tek sayılar:
            Console.WriteLine("Begin Odd");
            for (int i = 1; i <= 20; i += 2) // i += 2: i = i + 2
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("End Odd");

            // 2'den 20'ye kadar olan çift sayılar:
            Console.WriteLine("Begin Even");
            for (int i = 2; i <= 20; i = i + 2)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("End Even");

            // 20'den 2'ye kadar olan çift sayılar:
            Console.WriteLine("Begin Reverse Even");
            for (int i = 20; i >= 2; i -= 2)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("End Reverse Even");

            // index'in son değerini görme:
            int index;
            for (index = 1; index <= 5; index++)
            {

            }

            Console.WriteLine("Final index: " + index); // 6 olacaktır

            #endregion

            #region For Loop Demo

            // *'larla basit bir üçgen çizimi:
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }

                Console.WriteLine();
            }

            for (int i = 4; i >= 1; i--)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }

                Console.WriteLine();
            }

            #endregion

            #region While Loop

            // 1'den 10'a kadar olan sayılar:
            WhileLoop();

            #endregion

            #region Do While Loop

            // 1'den 10'a kadar olan sayılar:
            DoWhileLoop();
            // while ile do while arasındaki fark:
            WhileAndDoWhileLoop();

            #endregion

            #region For Each Loop

            string[] students = {"Çağıl", "Angel", "Leo"};
            ForEachLoop(students); // dizi (IEnumerable) temelli loop. üzerinde iterate edilebilir

            #endregion

            #region ++, --, +=, -=, *=, /= Operators
            // sayi++: sayi = sayi + 1, sayi += 1
            // sayi--: sayi = sayi - 1, sayi -= 1
            // sayi = sayi * 2: sayi *= 2
            // sayi = sayi / 3: sayi /= 3
            int sayi = 1;
            Console.WriteLine("Sayı: " + sayi++); // Sayı: 1
            sayi = 1;
            Console.WriteLine("Sayı: " + ++sayi); // Sayı: 2
            #endregion

            #region Asal Sayı Demo
            // Girilen bir sayı asal (prime number) mı:
            int number = 6;
            if (GirilenSayiAsalMi2(number))
            {
                Console.WriteLine("{0} is a prime number", number);
            }
            else
            {
                Console.WriteLine("{0} is not a prime number", number);
            }
            number = 13;
            if (GirilenSayiAsalMi2(number))
            {
                Console.WriteLine("{0} is a prime number", number);
            }
            else
            {
                Console.WriteLine("{0} is not a prime number", number);
            }
            number = 1;
            if (GirilenSayiAsalMi2(number))
            {
                Console.WriteLine("{0} is a prime number", number);
            }
            else
            {
                Console.WriteLine("{0} is not a prime number", number);
            }
            number = 2;
            if (GirilenSayiAsalMi2(number))
            {
                Console.WriteLine("{0} is a prime number", number);
            }
            else
            {
                Console.WriteLine("{0} is not a prime number", number);
            }
            number = 3;
            if (GirilenSayiAsalMi2(number))
            {
                Console.WriteLine("{0} is a prime number", number);
            }
            else
            {
                Console.WriteLine("{0} is not a prime number", number);
            }
            number = 18;
            if (GirilenSayiAsalMi2(number))
            {
                Console.WriteLine("{0} is a prime number", number);
            }
            else
            {
                Console.WriteLine("{0} is not a prime number", number);
            }
            number = 97;
            if (GirilenSayiAsalMi2(number))
            {
                Console.WriteLine("{0} is a prime number", number);
            }
            else
            {
                Console.WriteLine("{0} is not a prime number", number);
            }
            number = 98;
            if (GirilenSayiAsalMi2(number))
            {
                Console.WriteLine("{0} is a prime number", number);
            }
            else
            {
                Console.WriteLine("{0} is not a prime number", number);
            }

            GirilenSayiAsalMi1();
            #endregion

            #region Extras
            AsalSayi.AsalSayiMethod();
            Faktoriyel.FaktoriyelMethod();
            ForDongusu.ForDongusuMethod();
            DizilerDongulerLinq.DizilerDongulerLinqMethod();
            PlakalaraGoreSehirler.PlakalaraGoreSehirlerMethod();
            Palindrom.PalindromMethod();
            WhileDongusu.WhileDongusuMethod();
            IngilizceAlfabe.IngilizceAlfabeMethod();
            #endregion

            Console.ReadLine();
        }

        #region While Loop

        private static void WhileLoop() // Refactor ile türetildi
        {
            Console.WriteLine("Begin All");
            int i = 1;
            while (i <= 10)
            {
                Console.WriteLine(i);
                i++; // bu satır yazılmazsa infinite loop olur
            }

            Console.WriteLine("Final index: {0}", i);
            Console.WriteLine("End All");
        }

        #endregion

        #region Do While Loop

        private static void DoWhileLoop()
        {
            Console.WriteLine("Begin All");
            int i = 1;
            do
            {
                Console.WriteLine(i);
                i++; // bu satır yazılmazsa infinite loop olur
            } while (i <= 10);

            Console.WriteLine("Final index: {0}", i);
            Console.WriteLine("End All");
        }

        private static void WhileAndDoWhileLoop()
        {
            Console.WriteLine("Begin Do While");
            int i = 1;
            do
            {
                Console.WriteLine("Do While: " + i);
                i++; // bu satır yazılmazsa infinite loop olur
            } while (i < 1);

            Console.WriteLine("End Do While");
            Console.WriteLine("Begin While");
            i = 1;
            while (i < 1)
            {
                Console.WriteLine("While: " + i);
                i++; // bu satır yazılmazsa infinite loop olur
            }

            Console.WriteLine("End While");
        }

        #endregion

        #region For Each Loop

        private static void ForEachLoop(string[] names)
        {
            Console.WriteLine("Begin Names");
            foreach (var name in names)
            {
                //name = "Çağıl"; // hata verir, name readonly'dir
                Console.WriteLine(name);
            }

            Console.WriteLine("End Names");
        }

        #endregion

        #region Asal Sayı Demo
        private static void GirilenSayiAsalMi1()
        {
            int counter;
            Console.Write("Pozitif bir sayı giriniz, çıkmak için Q'ya basınız: ");
            string input = Console.ReadLine();
            int sayi;
            while (input != "q" && input != "Q")
            {
                counter = 0;
                sayi = Convert.ToInt32(input);
                for (int i = 2; i <= sayi; i++)
                {
                    if (sayi % i == 0)
                        counter++;
                }
                if (counter == 1)
                    Console.WriteLine("Asal sayı");
                else
                    Console.WriteLine("Asal olmayan sayı");
                Console.Write("Pozitif bir sayı giriniz, çıkmak için Q'ya basınız: ");
                input = Console.ReadLine();
            }
        }

        private static bool GirilenSayiAsalMi2(int number)
        {
            bool result = true;
            if (number == 1)
                result = false;
            for (int i = 2; i < number && result; i++) // 2: ilk asal sayı
            {
                if (number % i == 0)
                {
                    result = false;
                }
            }
            //for (int i = 2; i < number; i++) // 2: ilk asal sayı
            //{
            //    if (number % i == 0)
            //    {
            //        result = false;
            //        i = number; // for condition'ını sağlamaması için
            //    }
            //}
            //for (int i = 2; i < number; i++) // 2: ilk asal sayı
            //{
            //    if (number % i == 0)
            //    {
            //        result = false;
            //        break; // for'dan çıkmak için
            //    }
            //}
            return result;
        }
        #endregion
    }
}
