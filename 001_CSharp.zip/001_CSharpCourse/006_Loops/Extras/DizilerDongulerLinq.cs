﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _006_Loops.Extras
{
    class DizilerDongulerLinq
    {
        public static void DizilerDongulerLinqMethod()
        {
            // Diziler, for, foreach, do, do-while döngüleri, LINQ örneği (Ekstra)
            string[] isimler1 = new string[5];
            isimler1[0] = "Ahmet";
            isimler1[1] = "Mustafa";
            isimler1[2] = "Cem";
            isimler1[3] = "Ali";
            isimler1[4] = "Yasemin";
            for (int i = 0; i < isimler1.Length; i++)
                Console.WriteLine(isimler1[i]);

            string[] isimler2 = { "Hasan", "Cemal" };
            int j = 0;
            while (j < isimler2.Length)
            {
                Console.WriteLine("İsim: {0}", isimler2[j]);
                j++;
            }

            Console.Write("Aritmetik otalaması bulunacak kaç sayı gireceksiniz? ");
            int toplamSayi = int.Parse(Console.ReadLine());
            double[] sayilar = new double[toplamSayi];
            int k = 0;
            double toplam = 0;
            do
            {
                Console.Write((k + 1) + ". sayıyı giriniz: ");
                sayilar[k] = double.Parse(Console.ReadLine());
                toplam += sayilar[k];
                k++;
            } while (k < toplamSayi);
            Console.WriteLine("Aritmetik ortalama: " + toplam / toplamSayi);

            Console.WriteLine("Pozitif sayıların aritmetik ortalaması hesaplaması:");
            int l = 0; // Toplam sayı
            double sayi = 0;
            double sayilarinToplami = 0;
            while (sayi != -1)
            {
                Console.Write((l + 1) + ". sayıyı girin (-1 = Çıkış): ");
                sayi = Convert.ToDouble(Console.ReadLine());
                if (sayi != -1)
                {
                    sayilarinToplami += sayi;
                    l++;
                }
            }
            Console.WriteLine("Aritmetik ortalama: " + sayilarinToplami / l);

            String[] ogrenciler1 = new String[3];
            ogrenciler1[0] = "Ali";
            ogrenciler1[1] = "Mehmet";
            ogrenciler1[2] = "Zeynep";
            String[] ogrenciler2 = { "Cem", "Ali", "Yasemin", "Zeynep" };
            foreach (String ogrenci in ogrenciler1)
                Console.WriteLine(ogrenci);
            foreach (String ogrenci in ogrenciler2)
                Console.WriteLine(ogrenci);
            int kesisim = 0;
            foreach (String ogrenci1 in ogrenciler1)
            {
                foreach (String ogrenci2 in ogrenciler2)
                {
                    if (ogrenci1.Equals(ogrenci2))
                        kesisim++;
                }
            }
            Console.WriteLine("Ortak öğrenci sayısı: {0}", kesisim);

            string[] harfler = { "e", "a", "d", "b", "c" };
            var sirali = from harf in harfler
                         orderby harf
                         select harf;
            foreach (string deger in sirali)
                Console.WriteLine(deger);

            Random random = new Random();
            int[] numaralar = new int[5];
            for (int m = 0; m < numaralar.Length; m++)
            {
                numaralar[m] = random.Next(1, 6);
            }
            bool ortakNumara;
            int x;
            int n;
            for (x = 0; x < numaralar.Length; x++)
            {
                ortakNumara = false;
                for (n = x + 1; n < numaralar.Length && !ortakNumara; n++)
                {
                    if (numaralar[x] == numaralar[n])
                    {
                        ortakNumara = true;
                    }
                }
                if (ortakNumara)
                {
                    numaralar[n - 1] = random.Next(1, 6);
                    x = -1;
                    n = 1;
                }
            }
            int o = 0;
            Console.WriteLine("Random numaralar: ");
            do
            {
                Console.WriteLine(numaralar[o]);
                o++;
            } while (o < numaralar.Length);
            Console.WriteLine("Sıralı halleri: ");
            var siraliNumaralar = from numara in numaralar
                                  orderby numara
                                  select numara;
            foreach (int no in siraliNumaralar)
                Console.WriteLine(no);
            //Console.ReadLine();
        }
    }
}
