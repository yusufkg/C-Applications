﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _006_Loops.Extras
{
    class ForDongusu
    {
        public static void ForDongusuMethod()
        {
            // Döngüler:
            for (int i = 0; i < 10; i++) // i++ (++i)-> i = i + 1 (i += 1); i-- (--i) -> i = i - 1 (i -= 1)
                // int sayi1 = 1;
                // int sayi2 = 2;
                // sayi2 = sayi1++; sayi2 = 1, sayi1 = 2
                // sayi2 = ++sayi1; sayi2 = 2, sayi1 = 2
                // for'un içine istediğimiz kadar değişken yazabiliyoruz!
                Console.WriteLine("Cagil");

            int j;
            for (j = 0; j < 5;)
            {
                Console.WriteLine("Olur mu?");
                j++;
            }
            // for(; ; )
            // {
            //      Sonsuz döngü! (Başlangıç değeri yok, boolean değeri yok, arttırma veya azaltma değeri yok)
            // }

            int a, b, c;
            for (a = 0, b = 1, c = 2; a < (b + c); b--, c--)
            {
                Console.WriteLine(a + " " + b + " " + c);
            }

            //for (int k = 0; true; )
            //{
            //  Sonsuz döngü!
            //}

            //for (int k = 0; true; k++)
            //{
            //    satır execution'ı int'in maximum değerine ulaşana kadar devam eder.
            //}
            //Console.ReadLine();
        }
    }
}
