﻿using System;

namespace _006_Loops.Extras
{
    class AsalSayi
    {
        public static void AsalSayiMethod()
        {
            int sayi;
            bool asal = true;
            Console.Write("1 dışında pozitif bir tam sayı girin: ");
            sayi = Int32.Parse(Console.ReadLine());
            for (int i = 2; i < sayi; i++)
            {
                if (sayi % i == 0)
                {
                    asal = false;
                    break;
                }
            }
            if (asal)
                Console.Write(sayi + " sayısı asal.");
            else
                Console.Write(sayi + " sayısı asal değil.");
            Console.WriteLine();
            //Console.ReadLine();
        }
    }
}
