﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _006_Loops.Extras
{
    class Faktoriyel
    {
        public static void FaktoriyelMethod()
        {
            int sayi;
            int sonuc;
            Console.Write("Bir sayı girin: ");
            sayi = Int32.Parse(Console.ReadLine());
            sonuc = sayi;
            for (int i = 0; i < sayi; i++)
            {
                sonuc = sonuc * (sayi - 1);
                sayi--;
            }
            Console.WriteLine("Sayının faktöriyeli: " + sonuc);
            //Console.ReadLine();
        }
    }
}
