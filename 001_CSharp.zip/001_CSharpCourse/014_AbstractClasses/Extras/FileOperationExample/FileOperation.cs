﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _014_AbstractClasses.Extras.FileOperationExample
{
    class FileOperation : FileOperationBase
    {
        
    }
}
