﻿namespace _011_InterfaceSegregation.Extras.AracExample
{
    interface IKasaTipi
    {
        KasaTipiEnum KasaTipi { get; set; }
    }
}
