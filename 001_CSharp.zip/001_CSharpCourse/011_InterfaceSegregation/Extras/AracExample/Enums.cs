﻿namespace _011_InterfaceSegregation.Extras.AracExample
{
    enum YakitTipiEnum
    {
        Benzin,
        Dizel,
        Elektrik
    }

    enum KasaTipiEnum
    {
        Sedan,
        Hatchback,
        Cabrio,
        StationWagon
    }
}
