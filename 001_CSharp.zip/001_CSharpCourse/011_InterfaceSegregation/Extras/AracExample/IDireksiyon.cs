﻿namespace _011_InterfaceSegregation.Extras.AracExample
{
    interface IDireksiyon
    {
        bool DireksiyonSoldaMi { get; set; }
    }
}
