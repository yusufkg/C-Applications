﻿using System;

namespace _007_Strings.Extras
{
    class AboneNumarasi
    {
        public static void AboneNumarasiMethod()
        {
            // A123456-7 -> A: Abone Tipi (A: Bireysel, B: Kurumsal), 123456: Bina Numarası, 7: Daire Numarası
            string aboneNo = "A123456-7";

            // 1. Yöntem:
            if (aboneNo.StartsWith("A"))
                Console.WriteLine("Bireysel Abone");
            else
                Console.WriteLine("Kurumsal Abone");

            // 2. Yöntem:
            if (aboneNo.Substring(0, 1) == "A")
                Console.WriteLine("Bireysel Abone");
            else
                Console.WriteLine("Kurumsal Abone");

            // 3. Yöntem:
            if (aboneNo[0] == 'A')
                Console.WriteLine("Bireysel Abone");
            else
                Console.WriteLine("Kurumsal Abone");

            string aboneTipi = aboneNo.Substring(0, 1); // A
            string binaNo = aboneNo.Substring(1, 6); // 123456

            //string daireNo = aboneNo.Substring(8, aboneNo.Length - 8);
            string daireNo = aboneNo.Substring(8); // 7 -> Daha doğru kullanım 

            Console.WriteLine("Abone No: " + aboneNo +
                              "\nAbone Tipi: " + aboneTipi +
                              "\nBina No: " + binaNo + 
                              "\nDaire No: " + daireNo);
        }
    }
}
