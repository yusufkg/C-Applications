﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _007_Strings.Extras;

namespace _007_Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            #region String Veri Tipi
            // string: metinsel verileri tutmak için kullanılan veri tipidir
            // string: char[]
            // string'ler objedir, refere edilir

            #region Strings
            string city1 = "Ankara";
            Console.WriteLine(city1[0]);
            foreach (char city in city1)
            {
                Console.WriteLine(city);
            }

            string city2 = "İstanbul";
            string result1 = city1 + city2; // concatenate
            string result2 = city1 + " " + city2;
            Console.WriteLine(result2);
            string result3 = String.Format("{0} {1}", city1, city2);
            Console.WriteLine(result3);
            #endregion

            #region String Methods
            string sentence = "My name is Çağıl Alsaç";
            int sentenceLength = sentence.Length;
            object clonedSentence = sentence.Clone(); // yeni bir obje tipinde değişkene klonladık, sentence değişse de clonedSentence değişmeyecektir
            Console.WriteLine("Sentence: " + sentence);
            Console.WriteLine("Sentence Length: " + sentenceLength); // 22 gelecek
            sentence = sentence.Replace("Çağıl", "Leo");
            Console.WriteLine("Cloned Sentence: " + clonedSentence);
            if (sentence.EndsWith("ç"))
                Console.WriteLine("Sentence ends with 'ç'");
            else
                Console.WriteLine("Sentence doesn't end with 'ç'");
            if (sentence.StartsWith("Your name"))
                Console.WriteLine("Sentence starts with \"Your name\"");
            else
                Console.WriteLine("Sentence doesn't start with \"Your name\"");
            int indexOfIs = sentence.IndexOf("is");
            Console.WriteLine("Index of \"is\": " + indexOfIs);
            int indexOfCagil = sentence.IndexOf("çağıl");
            Console.WriteLine("Index of \"çağıl\": " + indexOfCagil); // case sensitive olduğundan bulamayacaktır ve -1 dönecektir
            int indexOfSpace = sentence.IndexOf(" ");
            Console.WriteLine("Index of space is: " + indexOfSpace); // ilk bulduğunu yani 2 dönecek
            int lastIndexOfSpace = sentence.LastIndexOf(" ");
            Console.WriteLine("Last index of space is: " + lastIndexOfSpace); // sondan başlayarak ilk bulduğunu yani 16 dönecek
            sentence = sentence.Insert(0, "Hello! ");
            Console.WriteLine(sentence);
            string subSentence = sentence.Substring(0, 6);
            Console.WriteLine(subSentence);
            subSentence = sentence.Substring(18);
            Console.WriteLine(subSentence);
            subSentence = sentence.Substring(7, 14);
            Console.WriteLine(subSentence);
            Console.WriteLine("Lower: " + sentence.ToLower() + "; " + "Upper: " + sentence.ToUpper());
            Console.WriteLine(sentence.Replace(" ", "_"));
            Console.WriteLine(sentence.Remove(5, 1));
            Console.WriteLine(sentence.Remove(5));
            sentence = sentence.Remove(0, 7);
            Console.WriteLine(sentence);
            string[] words = sentence.Split(' ');
            foreach (var word in words)
            {
                Console.WriteLine(word);
            }
            string leo = words[3];
            Console.WriteLine(leo);
            string test1 = "Test1";
            string test2 = "Test2";
            if (test1.Equals(test2))
                Console.WriteLine("{0} {1} {2}", test1, " = ", test2);
            else
                Console.WriteLine(test1 + " != " + test2);
            string ad = " Çağıl Alsaç ";
            Console.WriteLine("\"" + ad + "\"");
            Console.WriteLine("\"" + ad.Trim() + "\"");
            Console.WriteLine("\"" + ad.TrimStart() + "\"");
            Console.WriteLine("\"" + ad.TrimEnd() + "\"");
            Console.WriteLine(ad.Contains("ğ") ? "'ğ' var" : "'ğ' yok");
            #endregion

            #region Escape Sequences
            string name = "Çağıl";
            string escapeSequenceResult = "\"" + name + "\"";
            Console.WriteLine(escapeSequenceResult);
            string surname = "Alsaç";
            escapeSequenceResult = name + "\n" + surname;
            Console.WriteLine(escapeSequenceResult);
            escapeSequenceResult = name + "\t" + surname;
            Console.WriteLine(escapeSequenceResult);
            string path1 = "C:\\Users\\cagil";
            Console.WriteLine(path1);
            string path2 = @"C:\Users\cagil";
            Console.WriteLine(path2);
            /*
                \' – single quote, needed for character literals
                \" – double quote, needed for string literals
                \\ – backslash
                \0 – Unicode character 0
                \a – Alert (character 7)
                \b – Backspace (character 8)
                \f – Form feed (character 12)
                \n – New line (character 10)
                \r – Carriage return (character 13)
                \t – Horizontal tab (character 9)
                \v – Vertical quote (character 11)
                \uxxxx – Unicode escape sequence for character with hex value xxxx
                \xn[n][n][n] – Unicode escape sequence for character with hex value nnnn (variable length version of \uxxxx)
                \Uxxxxxxxx – Unicode escape sequence for character with hex value xxxxxxxx (for generating surrogates)
                Note: Of these, \a, \f, \v, \x and \U are rarely used.
            */
            #endregion

            #region StringsDemo1
            // bir string örneği üzerinde en sondan başlayarak ve string'in IndexOf() method'unu kullanarak verdiğimiz herhangi bir string değerinin index'ini bulalım
            string ornek = "As good as it gets.";
            string deger = "as";
            string terstenOrnek = Reverse(ornek);
            string terstenDeger = Reverse(deger);
            Console.WriteLine(terstenOrnek.IndexOf(terstenDeger));
            #endregion

            #region StringsDemo2
            // bir cümle içerisinde girilen kelimeyi case insensitive şekilde ve girilen kelimenin başındaki veya sonundaki boşlukları dikkate almayarak bulalım
            string cumle = "Merhaba benim adım Çağıl";
            Console.WriteLine("Cümle: " + cumle);
            Console.Write("Aranacak kelime: ");
            string kelime = Console.ReadLine();
            // 1. yöntem: Yanlış yöntem çünkü kelime yerine cümlenin içerisindeki girilen herhangi bir ifadeyi arıyor.
            //if (cumle.ToUpper().Contains(kelime.ToUpper().Trim()))
            //{
            //    Console.WriteLine("\"" + cumle + "\" cümlesi içerisinde \"" + kelime + "\" kelimesi bulundu.");
            //}
            //else
            //{
            //    Console.WriteLine("\"" + cumle + "\" cümlesi içerisinde \"" + kelime + "\" kelimesi bulunamadı.");
            //}
            // 2. yöntem: Doğru yöntem çünkü cümle içerisinde girilen kelimeyi arıyoruz.
            bool bulundu = false;
            string[] cumleKelimeleri = cumle.Split(' ');
            foreach (string cumleKelime in cumleKelimeleri)
            {
                //if (cumleKelime.ToUpper().Equals(kelime.ToUpper().Trim()))
                if (cumleKelime.ToUpper() == kelime.ToUpper().Trim())
                {
                    bulundu = true;
                    break;
                }
            }
            if (bulundu)
                Console.WriteLine("\"" + cumle + "\" cümlesi içerisinde \"" + kelime + "\" kelimesi bulundu.");
            else
                Console.WriteLine("\"" + cumle + "\" cümlesi içerisinde \"" + kelime + "\" kelimesi bulunamadı.");
            #endregion

            #region StringsDemo3
            // verilen bir isim soyisim listesi içerisinde kullanıcı tarafından girilen değer var mı (case insensitive ve baştaki veya sondaki boşlukları dikkate almadan arama). "çıkış" string'i girilerek programdan çıkılır
            string[] isimler = new string[5]
            {
                "Robert DeNiro",
                "Jennifer Lopez",
                "Robert Downey Jr.",
                "Al Pacino",
                "Kate Beckinsale"
            };
            Console.WriteLine("İsim listesi:");
            foreach (var isim in isimler)
            {
                Console.WriteLine(isim);
            }
            string[] caseInsensitiveIsimler = new string[5];
            int i = 0;
            foreach (var isim in isimler)
            {
                caseInsensitiveIsimler[i++] = isim.ToLower();
            }
            Console.Write("Aranacak ismi giriniz (\"çıkış\" yazarak çıkabilirsiniz): ");
            string input = Console.ReadLine();
            input = input.ToLower().Trim();
            bool found;
            while (!input.Equals("çıkış"))
            {
                found = false;
                for (i = 0; i < caseInsensitiveIsimler.Length && !found; i++)
                {
                    if (caseInsensitiveIsimler[i].Contains(input))
                        found = true;
                }
                if (found)
                    Console.WriteLine("\"" + input + "\" bulundu.");
                else
                    Console.WriteLine("\"" + input + "\" bulunamadı.");
                Console.Write("Aranacak ismi giriniz (\"çıkış\" yazarak çıkabilirsiniz): ");
                input = Console.ReadLine();
                input = input.ToLower().Trim();
            }
            #endregion

            #region StringsDemo4
            // verilen bir isim soyisim listesi içerisinde kullanıcı tarafından girilen değere göre bulunan isimleri listeleme (case insensitive ve baştaki veya sondaki boşlukları dikkate almadan arama). "çıkış" string'i girilerek programdan çıkılır
            string[] isimList = new string[5]
            {
                "Robert DeNiro",
                "Jennifer Lopez",
                "Robert Downey Jr.",
                "Al Pacino",
                "Kate Beckinsale"
            };
            Console.WriteLine("İsim listesi:");
            foreach (var isimItem in isimList)
            {
                Console.WriteLine(isimItem);
            }
            Console.Write("Aranacak ismi giriniz ('ç' ile çıkabilirsiniz): ");
            string aranacakIsim = Console.ReadLine();
            string[] bulunanIsimList;
            int bulunanIsimSayisi;
            int bulunanIsimIndex;
            while (!aranacakIsim.Equals("ç"))
            {
                Console.WriteLine("Bulunan isimler:");
                bulunanIsimSayisi = 0;
                foreach (string isimItem in isimList)
                {
                    if (isimItem.ToLower().Contains(aranacakIsim.ToLower().Trim()))
                        bulunanIsimSayisi++;
                }
                if (bulunanIsimSayisi > 0)
                {
                    bulunanIsimList = new string[bulunanIsimSayisi];
                    bulunanIsimIndex = 0;
                    for (int isimIndex = 0; isimIndex < isimList.Length; isimIndex++)
                    {
                        if (isimList[isimIndex].ToLower().Contains(aranacakIsim.ToLower().Trim()))
                        {
                            bulunanIsimList[bulunanIsimIndex] = isimList[isimIndex];
                            bulunanIsimIndex++;
                        }
                    }
                    foreach (string bulunanIsimItem in bulunanIsimList)
                    {
                        Console.WriteLine(bulunanIsimItem);
                    }
                }
                else
                {
                    Console.WriteLine("Aranan isim bulunamadı.");
                }
                Console.Write("Aranacak ismi giriniz ('ç' ile çıkabilirsiniz): ");
                aranacakIsim = Console.ReadLine();
            }
            #endregion

            #region StringsDemo5
            KelimeIlkHarfBuyukDigerleriKucuk.KelimeIlkHarfBuyukDigerleriKucukMethod();
            #endregion

            #region StringsDemo6
            // İsim bulma oyunu
            IsimBulmaOyunu.IsimBulmaOyunuMethod();
            #endregion

            #region StringsDemo7
            AboneNumarasi.AboneNumarasiMethod();
            #endregion
            #endregion

            #region DateTime Veri Tipi
            // DateTime tarih ve saat verilerini tutan struct yapıda bir değer tiptir.
            DateTime simdikiTarih = DateTime.Now;
            Console.WriteLine("Şimdiki tarih ve saat: " + simdikiTarih);
            Console.WriteLine("Şimdiki tarih (kısa): " + simdikiTarih.ToShortDateString());
            Console.WriteLine("Şimdiki tarih (uzun): " + simdikiTarih.ToLongDateString());
            Console.WriteLine("Şimdiki saat (kısa): " + simdikiTarih.ToShortTimeString());
            Console.WriteLine("Şimdiki saat (uzun): " + simdikiTarih.ToLongTimeString());
            Console.WriteLine("Bugün: " + simdikiTarih.ToShortDateString() + " " + simdikiTarih.ToLongTimeString());
            Console.WriteLine("Şimdiki tarih ve saat: " + simdikiTarih.Day + "." + simdikiTarih.Month + "." + simdikiTarih.Year + " "
                              + simdikiTarih.Hour + ":" + simdikiTarih.Minute + ":" + simdikiTarih.Second + "." + simdikiTarih.Millisecond);
            Console.WriteLine(simdikiTarih.Day.ToString().PadLeft(2, '0') + "." + simdikiTarih.Month.ToString().PadLeft(2, '0') + "."
                              + simdikiTarih.Year + " " + simdikiTarih.Hour.ToString().PadLeft(2, '0') + ":"
                              + simdikiTarih.Minute.ToString().PadLeft(2, '0') + ":" + simdikiTarih.Second.ToString().PadLeft(2, '0') + "."
                              + simdikiTarih.Millisecond.ToString().PadLeft(3, '0'));

            DateTime otuzEylulIkiBinYirmi = new DateTime(2020, 9, 30);
            DateTime otuzEylulIkiBinYirmiYediKirkBes = new DateTime(2020, 9, 30, 7, 45, 0, 0);
            otuzEylulIkiBinYirmiYediKirkBes = new DateTime(2020, 9, 30, 7, 45, 0);
            Console.WriteLine("Tarih: Otuz Eylül İki Bin Yirmi: " + otuzEylulIkiBinYirmi.ToShortDateString());
            Console.WriteLine("Tarih ve Saat: Otuz Eylül İki Bin Yirmi ve Yedi Kırk Beş: " + otuzEylulIkiBinYirmiYediKirkBes);

            string dateTime = "27.06.2021 09:33";
            string[] dateTimeArray = dateTime.Split(' ');
            string date = dateTimeArray[0];
            string[] datePartsArray = date.Split('.');
            string day = datePartsArray[0];
            string month = datePartsArray[1];
            string year = datePartsArray[2];
            string time = dateTimeArray[1];
            string[] timePartsArray = time.Split(':');
            string hour = timePartsArray[0];
            string minute = timePartsArray[1];
            DateTime dateTimeStruct1 = new DateTime(
                Convert.ToInt32(year), Convert.ToInt32(month), Convert.ToInt32(day),
                Convert.ToInt32(hour), Convert.ToInt32(minute), 0);
            Console.WriteLine("Date time: " + dateTimeStruct1);
            var dateTimeStruct2 = DateTime.Parse(dateTime);
            Console.WriteLine("Date time: " + dateTimeStruct2);

            var yirmiEkimIkiBinYirmi = DateTime.Parse("20.10.2020", new CultureInfo("tr"));
            Console.WriteLine("Türkçe formatlı tarih: Yirmi Ekim İki Bin Yirmi: " + yirmiEkimIkiBinYirmi.ToString(new CultureInfo("tr")));
            yirmiEkimIkiBinYirmi = DateTime.Parse("10/20/2020", new CultureInfo("en"));
            Console.WriteLine("İngilizce formatlı tarih: Yirmi Ekim İki Bin Yirmi: " + yirmiEkimIkiBinYirmi.ToString(new CultureInfo("en")));
            Console.WriteLine("SQL formatlı tarih: Yirmi Ekim İki Bin Yirmi: " + yirmiEkimIkiBinYirmi.ToString("yyyy-MM-dd HH:mm:ss"));

            simdikiTarih = DateTime.Now;
            Console.WriteLine("Bugün: " + simdikiTarih);
            Console.WriteLine("Yarın: " + simdikiTarih.AddDays(1).ToShortDateString());
            Console.WriteLine("1 hafta öncesi: " + simdikiTarih.AddDays(-7).ToShortDateString());
            Console.WriteLine("6 ay sonrası: " + simdikiTarih.AddMonths(6).ToShortDateString());
            Console.WriteLine("10 yıl öncesi: " + simdikiTarih.AddYears(-10).ToShortDateString());
            Console.WriteLine("12 saat sonrası: " + simdikiTarih.AddHours(12));
            Console.WriteLine("Yarım saat öncesi: " + simdikiTarih.AddMinutes(-30));

            var tarih1 = DateTime.Parse("01.10.2020");
            var tarih2 = DateTime.Parse("20.10.2020");
            if (tarih2.CompareTo(tarih1) > 0)
                Console.WriteLine(tarih2 + " > " + tarih1);
            else if (tarih2.CompareTo(tarih1) < 0)
                Console.WriteLine(tarih2 + " < " + tarih1);
            else //if (tarih2.CompareTo(tarih1) == 0)
                Console.WriteLine(tarih2 + " = " + tarih1);
            if (tarih2 > tarih1)
                Console.WriteLine(tarih2 + " > " + tarih1);
            else if (tarih2 < tarih1)
                Console.WriteLine(tarih2 + " < " + tarih1);
            else //if (tarih2 == tarih1) veya if (tarih2.Equals(tarih1))
                Console.WriteLine(tarih2 + " = " + tarih1);

            simdikiTarih = DateTime.Now;
            Console.WriteLine("Şimdiki tarih ve saat: " + simdikiTarih + ", haftanın günü: " + simdikiTarih.DayOfWeek + "(" + (int)simdikiTarih.DayOfWeek + "), yılın günü: " + simdikiTarih.DayOfYear);
            Console.WriteLine("Şimdiki tarihin tick değeri: " + simdikiTarih.Ticks);

            Console.WriteLine("Şimdiki tarih ve saat: " + DateTime.Now + ",\nsadece şimdiki tarih (Date ile): " + DateTime.Now.Date + ",\nsadece şimdiki tarih (Today ile): " + DateTime.Today);
            #endregion

            #region Math Kütüphanesi
            Console.WriteLine("Pi Sayısı: " + Math.PI);
            int sayi1 = 10;
            int sayi2 = 20;
            Console.WriteLine("sayi1 - sayi2 = " + (sayi1 - sayi2) + ", Mutlak değeri: " + Math.Abs(sayi1 - sayi2));
            double sayi3 = 2.4;
            Console.WriteLine("sayi3 taban değeri: " + Math.Floor(sayi3) + ", sayi3 tavan değeri: " + Math.Ceiling(sayi3));
            Console.WriteLine("2 üzeri 4: " + Math.Pow(2, 4));
            Console.WriteLine("2 ve 4 için büyük olan sayı: " + Math.Max(2, 4) + ", küçük olan sayı: " + Math.Min(2, 4));
            double sayi4 = 12.345;
            double sayi5 = 98.765;
            Console.WriteLine("sayi4 yuvarlanmış: " + Math.Round(sayi4) + ", sayi5 yuvarlanmış: " + Math.Round(sayi5));
            Console.WriteLine("sayi4 1 ondalık için yuvarlanmış: " + Math.Round(sayi4, 1) + ", sayi5 1 ondalık için yuvarlanmış: " + Math.Round(sayi5, 1));
            Console.WriteLine("sayi4 2 ondalık için yuvarlanmış: " + Math.Round(sayi4, 2) + ", sayi5 2 ondalık için yuvarlanmış: " + Math.Round(sayi5, 2));
            Console.WriteLine("4 sayısının kare kökü: " + Math.Sqrt(4) + ", 16 sayısının kare kökü: " + Math.Sqrt(16));

            Console.WriteLine("8 sayısının küp kökü: " + Math.Pow(8, 1 / 3)); // 1 / 3 = 0, 8 ^ 0 = 1
            Console.WriteLine("8 sayısının küp kökü: " + Math.Pow(8, 1.0 / 3)); // 1.0 / 3 = 0.333..., 8 ^ 0.333... = 2
            Console.WriteLine("8 sayısının küp kökü: " + Math.Pow(8, 1 / 3.0)); // 1 / 3.0 = 0.333..., 8 ^ 0.333... = 2
            Console.WriteLine("8 sayısının küp kökü: " + Math.Pow(8, 1.0 / 3.0)); // 1.0 / 3.0 = 0.333..., 8 ^ 0.333... = 2
            #endregion

            #region Yaş Hesaplama Demo
            Console.Write("Doğum tarihi girin (gün.ay.yıl): ");
            string dogumTarihiInput = Console.ReadLine();
            DateTime dogumTarihi = DateTime.Parse(dogumTarihiInput, new CultureInfo("tr"));
            //DateTime bugun = DateTime.Now;
            //DateTime bugun = DateTime.Now.Date;
            DateTime bugun = DateTime.Today;
            double yas;
            // 1. yöntem:
            //yas = bugun.Year - dogumTarihi.Year; // yarınki ve daha sonraki gün ve aylar için yanlış hesaplıyor
            // 2. yöntem: Doğru hesaplama
            TimeSpan tarihFarki = bugun.Subtract(dogumTarihi); // şimdiki tarih ve saatten doğum tarihini çıkarıp bir süre elde ediyoruz
            yas = Math.Floor(tarihFarki.TotalHours / (365 * 24 + 6)); // elde ettiğimiz sürenin toplam saati üzerinden 1 yıl = 365 gün + 6 saat'e göre işlem yaparak sonucu aşağı yuvarlıyoruz
            Console.WriteLine("Yaşınız: " + yas);
            #endregion

            #region T.C. Kimlik No Doğrulama Demo
            Console.Write("T.C. Kimlik No: ");
            string giris = Console.ReadLine();
            if (giris.Length != 11)
            {
                Console.WriteLine("T.C. Kimlik No 11 hane olmalıdır!");
            }
            else
            {
                //if (giris.StartsWith("0"))
                if (giris.Substring(0, 1) == "0")
                {
                    Console.Write("T.C. Kimlik No ilk hanesi 0 olamaz!");
                }
                else
                {
                    double[] haneler = new double[giris.Length];
                    for (int h = 0; h < haneler.Length; h++)
                    {
                        haneler[h] = Convert.ToDouble(giris[h].ToString());
                    }
                    double hane10toplam1 = haneler[0] + haneler[2] + haneler[4] + haneler[6] + haneler[8];
                    double hane10toplam2 = haneler[1] + haneler[3] + haneler[5] + haneler[7];
                    double hane10 = (hane10toplam1 * 7 - hane10toplam2) % 10;
                    if (hane10 != haneler[9])
                    {
                        Console.WriteLine("T.C. Kimlik No doğru değildir!");
                    }
                    else
                    {
                        double hane11toplam = 0;
                        for (int h = 0; h < haneler.Length - 1; h++)
                        {
                            hane11toplam += haneler[h];
                        }
                        double hane11 = hane11toplam % 10;
                        if (hane11 != haneler[10])
                        {
                            Console.WriteLine("T.C. Kimlik No doğru değildir!");
                        }
                        else
                        {
                            Console.WriteLine("T.C.Kimlik No doğrudur.");
                        }
                    }
                }
            }
            #endregion

            Console.ReadLine();
        }

        #region String Veri Tipi
        #region StringsDemo1
        static string Reverse(string input)
        {
            string output = "";
            for (int i = input.Length - 1; i >= 0; i--)
            {
                output += input[i];
            }
            return output;
        }
        #endregion
        #endregion
    }
}
