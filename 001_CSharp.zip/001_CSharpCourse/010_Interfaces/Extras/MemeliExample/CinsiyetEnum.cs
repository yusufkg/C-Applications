﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _010_Interfaces.Extras.MemeliExample
{
    enum CinsiyetEnum
    {
        Dişi,
        Erkek
    }
}
