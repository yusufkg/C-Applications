﻿namespace _026_Workshop_3_Console.Config
{
    static class DataSourceConfig
    {
        static DataSource.PersonelDataSource.IDataSource personelDataSource = null;
        static DataSource.DegerlendirmeDataSource.IDataSource degerlendirmeDataSource = null;

        public static DataSource.PersonelDataSource.IDataSource UseMemoryDataSourcePersonel()
        {
            if (personelDataSource == null)
                personelDataSource = new DataSource.PersonelDataSource.MemoryDataSource();
            return personelDataSource;
        }

        public static DataSource.PersonelDataSource.IDataSource UseFileDataSourcePersonel()
        {
            if (personelDataSource == null)
                personelDataSource = new DataSource.PersonelDataSource.FileDataSource();
            return personelDataSource;
        }

        public static DataSource.DegerlendirmeDataSource.IDataSource UseFileDataSourceDegerlendirme()
        {
            if (degerlendirmeDataSource == null)
                degerlendirmeDataSource = new DataSource.DegerlendirmeDataSource.FileDataSource();
            return degerlendirmeDataSource;
        }
    }
}
