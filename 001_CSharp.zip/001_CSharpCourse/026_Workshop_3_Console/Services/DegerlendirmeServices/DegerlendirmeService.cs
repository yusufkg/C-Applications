﻿using _026_Workshop_3_Console.Data.DegerlendirmeData;
using _026_Workshop_3_Console.DataSource.DegerlendirmeDataSource;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _026_Workshop_3_Console.Services.DegerlendirmeServices
{
    class DegerlendirmeService
    {
        IDataSource dataSource;

        public DegerlendirmeService(IDataSource _dataSource)
        {
            dataSource = _dataSource;
        }

        public List<Degerlendirme> GetList()
        {
            List<Degerlendirme> degerlendirmeList = null;
            try
            {
                degerlendirmeList = dataSource.GetDegerlendirmeList();
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return degerlendirmeList;
        }

        public Degerlendirme GetById(int id)
        {
            Degerlendirme degerlendirme = null;
            try
            {
                var degerlendirmeler = GetList();
                foreach (var _degerlendirme in degerlendirmeler)
                {
                    if (_degerlendirme.Id == id)
                    {
                        degerlendirme = _degerlendirme;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return degerlendirme;
        }

        public void Update(Degerlendirme degerlendirme)
        {
            dataSource.Update(degerlendirme);
        }
    }
}
