﻿using _026_Workshop_3_Console.Data.PersonelData;
using _026_Workshop_3_Console.DataSource.PersonelDataSource;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _026_Workshop_3_Console.Services.PersonelServices
{
    class PersonelService
    {
        IDataSource dataSource;

        public PersonelService(IDataSource _dataSource)
        {
            dataSource = _dataSource;
        }

        public List<Personel> GetList()
        {
            List<Personel> personelList = null;
            try
            {
                personelList = dataSource.GetPersonelList();
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return personelList;
        }

        public Personel GetById(int id)
        {
            Personel personel = null;
            try
            {
                var personeller = GetList();
                foreach (var _personel in personeller)
                {
                    if (_personel.Id == id)
                    {
                        personel = _personel;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return personel;
        }

        public void Add(Personel personel)
        {
            dataSource.Add(personel);
        }

        public void Update(Personel personel)
        {
            dataSource.Update(personel);
        }

        public void Delete(int id)
        {
            dataSource.Delete(id);
        }
    }
}
