﻿using _026_Workshop_3_Console.Data.PersonelData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _026_Workshop_3_Console.DataSource.PersonelDataSource
{
    class MemoryDataSource : IDataSource
    {
        private List<Personel> personelList;

        public MemoryDataSource()
        {
            personelList = new List<Personel>()
            {
                new Personel()
                {
                    Id = 1,
                    FirstName = "Çağıl",
                    LastName = "Alsaç",
                    Address = "Çankaya, Ankara",
                    Phone = 5321234567,
                    Birthday = new DateTime(1980, 5, 1),
                    Department = "AR-GE"
                },
                new Personel()
                {
                    Id = 2,
                    FirstName = "Ali",
                    LastName = "Bayram",
                    Address = "Yenimahalle, Ankara",
                    Department = "İK"
                },
                new Personel()
                {
                    Id = 3,
                    FirstName = "Zeynep",
                    LastName = "Tan",
                    Address = "Bakırköy, İstanbul",
                    Birthday = new DateTime(1989, 1, 2),
                    Department = "İK"
                },
                new Personel()
                {
                    Id = 4,
                    FirstName = "Yasemin",
                    LastName = "Çetin",
                    Address = "Bornova, İzmir",
                    Phone = 5429876543,
                    Birthday = new DateTime(1970, 12, 13),
                    Department = "AR-GE"
                }
            };
        }

        public void Add(Personel personel)
        {
            personelList.Add(personel);
        }

        public List<Personel> GetPersonelList()
        {
            return personelList;
        }

        public void Update(Personel personel)
        {
            for (int i = 0; i < personelList.Count; i++)
            {
                if (personel.Id == personelList[i].Id)
                {
                    personelList[i] = personel;
                    break;
                }
            }
        }

        public void Delete(int id)
        {
            foreach (var p in personelList)
            {
                if (p.Id == id)
                {
                    personelList.Remove(p);
                    break;
                }
            }
        }
    }
}
