﻿using _026_Workshop_3_Console.Data.PersonelData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _026_Workshop_3_Console.DataSource.PersonelDataSource
{
    interface IDataSource
    {
        List<Personel> GetPersonelList();
        void Add(Personel personel);
        void Update(Personel personel);
        void Delete(int id);
    }
}
