﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _026_Workshop_3_Console.Data.PersonelData;
using _026_Workshop_3_Console.Utils;

namespace _026_Workshop_3_Console.DataSource.PersonelDataSource
{
    class FileDataSource : IDataSource
    {
        private string _path;

        public FileDataSource()
        {
            string assemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            string exeFileName = assemblyName + ".exe";
            string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            _path = exePath.Replace(@"bin\Debug\" + exeFileName, @"DataSource\PersonelDataSource\PersonelListesi.txt");
        }

        public FileDataSource(string path)
        {
            _path = path;
        }

        public void Add(Personel personel)
        {
            StreamWriter writer = null;
            try
            {
                string line = "";
                writer = new StreamWriter(_path, true, Encoding.UTF8);
                line += personel.Id.ToString() + "~";
                line += personel.FirstName + "~";
                line += personel.LastName + "~";
                line += personel.Address + "~";
                line += (personel.Phone == null ? "" : personel.Phone.ToString()) + "~";
                line += (personel.Birthday.HasValue ? personel.Birthday.Value.ToString("yyyy-MM-dd") : "") + "~";
                line += personel.Department;
                writer.WriteLine(line);
                writer.Close();
            }
            catch (Exception exc)
            {
                if (writer != null)
                    writer.Close();
                throw exc;
            }
        }

        public void Delete(int id)
        {
            try
            {
                File.Copy(_path, _path.Replace("PersonelListesi.txt", "tmpPersonelListesi.txt"), true);
                var personeller = GetPersonelList();
                File.WriteAllText(_path, "");
                for (int i = 0; i < personeller.Count; i++)
                {
                    if (personeller[i].Id != id)
                    {
                        Add(personeller[i]);
                    }
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public List<Personel> GetPersonelList()
        {
            List<Personel> personelListesi = new List<Personel>();
            Personel personel;
            string[] personelStringArray;
            string tmpPersonelString;
            //int yil, ay, gun;
            StreamReader reader = null;
            try
            {
                reader = new StreamReader(_path, Encoding.UTF8);
                while (!reader.EndOfStream)
                {
                    personelStringArray = StringUtil.GetStringArrayBySeperator(reader.ReadLine(), "~".ToCharArray());
                    personel = new Personel();
                    personel.Id = Convert.ToInt32(personelStringArray[0]);
                    personel.FirstName = personelStringArray[1];
                    personel.LastName = personelStringArray[2];
                    personel.Address = personelStringArray[3];
                    tmpPersonelString = personelStringArray[4];
                    if (tmpPersonelString == null || tmpPersonelString == "")
                        personel.Phone = null;
                    else
                        personel.Phone = Convert.ToInt64(tmpPersonelString);
                    tmpPersonelString = personelStringArray[5];
                    if (tmpPersonelString == null || tmpPersonelString == "")
                    {
                        personel.Birthday = null;
                    }
                    else
                    {
                        //yil = Convert.ToInt32(tmpPersonelString.Substring(0, 4));
                        //ay = Convert.ToInt32(tmpPersonelString.Substring(5, 2));
                        //gun = Convert.ToInt32(tmpPersonelString.Substring(8));
                        //personel.Birthday = new DateTime(yil, ay, gun);
                        personel.Birthday = DateTime.Parse(tmpPersonelString);
                    }
                    personel.Department = personelStringArray[6];
                    personelListesi.Add(personel);
                }
            }
            catch (Exception exc)
            {
                personelListesi = null;
                throw exc;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
            return personelListesi;
        }

        public void Update(Personel personel)
        {
            try
            {
                var personeller = GetPersonelList();
                for (int i = 0; i < personeller.Count; i++)
                {
                    if (personeller[i].Id == personel.Id)
                    {
                        personeller[i] = personel;
                        break;
                    }
                }
                File.Copy(_path, _path.Replace("PersonelListesi.txt", "tmpPersonelListesi.txt"), true);
                File.WriteAllText(_path, "");
                foreach (var p in personeller)
                {
                    Add(p);
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }
    }
}
