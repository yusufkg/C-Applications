﻿using _026_Workshop_3_Console.Data.DegerlendirmeData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _026_Workshop_3_Console.DataSource.DegerlendirmeDataSource
{
    interface IDataSource
    {
        List<Degerlendirme> GetDegerlendirmeList();
        void Update(Degerlendirme degerlendirme);
        void Add(Degerlendirme degerlendirme);
    }
}
