﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _026_Workshop_3_Console.Data.DegerlendirmeData;
using _026_Workshop_3_Console.Utils;

namespace _026_Workshop_3_Console.DataSource.DegerlendirmeDataSource
{
    class FileDataSource : IDataSource
    {
        private string _path;

        public FileDataSource()
        {
            string assemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            string exeFileName = assemblyName + ".exe";
            string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            _path = exePath.Replace(@"bin\Debug\" + exeFileName, @"DataSource\DegerlendirmeDataSource\DeğerlendirmeListesi.txt");
        }

        public FileDataSource(string path)
        {
            _path = path;
        }

        public List<Degerlendirme> GetDegerlendirmeList()
        {
            List<Degerlendirme> degerlendirmeListesi = new List<Degerlendirme>();
            Degerlendirme degerlendirme;
            string[] degerlendirmeStringArray;
            string tmpDegerlendirmeString;
            StreamReader reader = null;
            try
            {
                reader = new StreamReader(_path, Encoding.UTF8);
                while (!reader.EndOfStream)
                {
                    degerlendirmeStringArray = StringUtil.GetStringArrayBySeperator(reader.ReadLine(), ";".ToCharArray());
                    degerlendirme = new Degerlendirme();
                    degerlendirme.Id = Convert.ToInt32(degerlendirmeStringArray[0]);
                    degerlendirme.Konu = degerlendirmeStringArray[1];
                    degerlendirme.Grup = degerlendirmeStringArray[2];
                    degerlendirme.KisiVeDegerlendirmeler = degerlendirmeStringArray[3];
                    degerlendirme.OrtalamaDegerlendirme = Convert.ToDouble(degerlendirmeStringArray[4], new CultureInfo("tr"));
                    degerlendirme.DegerlendirmeTarihi = DateTime.Parse(degerlendirmeStringArray[5]);
                    degerlendirmeListesi.Add(degerlendirme);
                }
            }
            catch (Exception exc)
            {
                degerlendirmeListesi = null;
                throw exc;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
            return degerlendirmeListesi;
        }

        public void Update(Degerlendirme degerlendirme)
        {
            try
            {
                var degerlendirmeList = GetDegerlendirmeList();
                for (int i = 0; i < degerlendirmeList.Count; i++)
                {
                    if (degerlendirmeList[i].Id == degerlendirme.Id)
                    {
                        degerlendirmeList[i] = degerlendirme;
                    }
                }
                File.WriteAllText(_path, "");
                foreach (var d in degerlendirmeList)
                {
                    Add(d);
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void Add(Degerlendirme degerlendirme)
        {
            StreamWriter writer = null;
            try
            {
                string line = "";
                writer = new StreamWriter(_path, true, Encoding.UTF8);
                line += degerlendirme.Id.ToString() + ";";
                line += degerlendirme.Konu + ";";
                line += degerlendirme.Grup + ";";
                line += degerlendirme.KisiVeDegerlendirmeler + ";";
                line += degerlendirme.OrtalamaDegerlendirme + ";";
                line += degerlendirme.DegerlendirmeTarihi.ToShortDateString() + " " + degerlendirme.DegerlendirmeTarihi.ToShortTimeString();
                writer.WriteLine(line);
                writer.Close();
            }
            catch (Exception exc)
            {
                if (writer != null)
                    writer.Close();
                throw exc;
            }
        }
    }
}
