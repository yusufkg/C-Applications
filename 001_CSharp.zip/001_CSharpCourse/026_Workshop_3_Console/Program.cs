﻿using _026_Workshop_3_Console.Config;
using _026_Workshop_3_Console.Data.DegerlendirmeData;
using _026_Workshop_3_Console.Data.PersonelData;
using _026_Workshop_3_Console.Services.DegerlendirmeServices;
using _026_Workshop_3_Console.Services.PersonelServices;
using _026_Workshop_3_Console.Utils;
using System;
using System.Globalization;

namespace _026_Workshop_3_Console
{
    // 1) Basit bir in-memory veya file veri kaynağını kullanan Personel Bilgi Sistemi.
    // 2) Basit bir file veri kaynağını kullanan Konu Değerlendirme Sistemi.

    class Program
    {
        static DataSource.PersonelDataSource.IDataSource personelDataSource;
        static DataSource.DegerlendirmeDataSource.IDataSource degerlendirmeDataSource;
        static PersonelService personelService;
        static DegerlendirmeService degerlendirmeService;

        static void Main(string[] args)
        {
            #region Personel
            //personelDataSource = DataSourceConfig.UseMemoryDataSourcePersonel();
            //personelService = new PersonelService(personelDataSource);
            //DisplayPersonelList();
            //DisplayPersonelById();
            //AddNewPersonel();
            //DisplayPersonelList();
            //UpdatePersonel();
            //DisplayPersonelList();
            //DeletePersonel();
            //DisplayPersonelList();
            #endregion

            #region Değerlendirme
            degerlendirmeDataSource = DataSourceConfig.UseFileDataSourceDegerlendirme();
            degerlendirmeService = new DegerlendirmeService(degerlendirmeDataSource);
            DisplayDegerlendirmeList();
            DisplayDegerlendirmeById();
            UpdateDegerlendirme();
            DisplayDegerlendirmeList();
            DisplayDegerlendirmeById();
            #endregion

            Console.ReadLine();
        }

        private static void UpdateDegerlendirme()
        {
            try
            {
                Console.WriteLine("Lütfen güncellemek istediğiniz değerlendirmenin ID'sini giriniz: ");
                int id;
                if (Int32.TryParse(Console.ReadLine().Trim(), out id))
                {
                    var degerlendirme = degerlendirmeService.GetById(id);
                    if (degerlendirme == null)
                    {
                        Console.WriteLine("Değerlendirme bulunamadı.");
                        return;
                    }
                    bool setDegerlendirmeBilgileriResult = SetDegerlendirmeBilgileri(degerlendirme);
                    if (setDegerlendirmeBilgileriResult == false)
                        return;
                    degerlendirmeService.Update(degerlendirme);
                }
                else
                {
                    Console.WriteLine("Değerlendirme bulunamadı.");
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }

        private static bool SetDegerlendirmeBilgileri(Degerlendirme degerlendirme)
        {
            bool result = true;
            try
            {
                string kisiVeDegerlendirme;
                double ortalamaDegerlendirme;
                double degerlendirmeDouble;
                string degerlendirmeString;
                string[] kisiVeDegerlendirmeler = StringUtil.GetStringArrayBySeperator(degerlendirme.KisiVeDegerlendirmeler, "-".ToCharArray());
                string kisi;
                int tmpDegerlendirmeInt;
                Console.WriteLine("\"" + degerlendirme.Id + " - " + degerlendirme.Konu + "\" için kişi değerlendirmeleri: ");
                kisiVeDegerlendirme = "";
                ortalamaDegerlendirme = 0;
                degerlendirmeDouble = 0;
                for (int i = 0; i < kisiVeDegerlendirmeler.Length && result; i++)
                {
                    kisi = StringUtil.GetStringArrayBySeperator(kisiVeDegerlendirmeler[i].Trim(), ":".ToCharArray())[0];
                    kisiVeDegerlendirme += kisi + ":";
                    Console.Write(kisi + " değerlendirmesi (1 - 5): ");
                    degerlendirmeString = Console.ReadLine().Trim();
                    if (String.IsNullOrWhiteSpace(degerlendirmeString))
                    {
                        Console.WriteLine("Değerlendirme boş olamaz.");
                        result = false;
                    }
                    if (!Int32.TryParse(degerlendirmeString, out tmpDegerlendirmeInt))
                    {
                        Console.WriteLine("Değerlendirme sadece 1 ile 5 arasında olabilir.");
                        result = false;
                    }
                    else
                    {
                        if (tmpDegerlendirmeInt >= 1 && tmpDegerlendirmeInt <= 5)
                        {
                            kisiVeDegerlendirme += degerlendirmeString + " - ";
                            degerlendirmeDouble += tmpDegerlendirmeInt;
                            ortalamaDegerlendirme = degerlendirmeDouble / kisiVeDegerlendirmeler.Length;
                        }
                        else
                        {
                            Console.WriteLine("Değerlendirme sadece 1 ile 5 arasında olabilir.");
                            result = false;
                        }
                    }
                }
                if (result == true)
                {
                    degerlendirme.KisiVeDegerlendirmeler = kisiVeDegerlendirme.TrimEnd(" - ".ToCharArray());
                    degerlendirme.OrtalamaDegerlendirme = ortalamaDegerlendirme;
                    degerlendirme.DegerlendirmeTarihi = DateTime.Now;
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
                result = false;
            }
            return result;
        }

        private static void DisplayDegerlendirmeById()
        {
            try
            {
                Console.WriteLine("Lütfen detayını görmek istediğiniz değerlendirmenin ID'sini giriniz: ");
                int id;
                if (Int32.TryParse(Console.ReadLine().Trim(), out id))
                {
                    var degerlendirme = degerlendirmeService.GetById(id);
                    if (degerlendirme != null)
                    {
                        Console.WriteLine("Id = " + degerlendirme.Id + ", Konu = " + degerlendirme.Konu + ", Grup = " + degerlendirme.Grup + ", Kişiler ve Değerlendirmeler = " + degerlendirme.KisiVeDegerlendirmeler + ", Ortalama Değerlendirme = " + degerlendirme.OrtalamaDegerlendirme.ToString() + ", Tarih = " +
                          degerlendirme.DegerlendirmeTarihi.ToShortDateString() + " " + degerlendirme.DegerlendirmeTarihi.ToShortTimeString());
                    }
                    else
                    {
                        Console.WriteLine("Değerlendirme bulunamadı.");
                    }
                }
                else
                {
                    Console.WriteLine("Değerlendirme bulunamadı.");
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }

        private static void DisplayDegerlendirmeList()
        {
            try
            {
                var degerlendirmeler = degerlendirmeService.GetList();
                foreach (var degerlendirme in degerlendirmeler)
                {
                    Console.WriteLine("Id = " + degerlendirme.Id + ", Konu = " + degerlendirme.Konu + ", Grup = " + degerlendirme.Grup + ", Kişiler ve Değerlendirmeler = " + degerlendirme.KisiVeDegerlendirmeler + ", Ortalama Değerlendirme = " + degerlendirme.OrtalamaDegerlendirme.ToString() + ", Tarih = " +
                      degerlendirme.DegerlendirmeTarihi.ToShortDateString() + " " + degerlendirme.DegerlendirmeTarihi.ToShortTimeString());
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }

        private static void DeletePersonel()
        {
            try
            {
                Console.WriteLine("Lütfen silmek istediğiniz personelin ID'sini giriniz: ");
                int id = Convert.ToInt32(Console.ReadLine());
                personelService.Delete(id);
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }

        private static void UpdatePersonel()
        {
            try
            {
                Console.WriteLine("Lütfen güncellemek istediğiniz personelin ID'sini giriniz: ");
                int id = Convert.ToInt32(Console.ReadLine());
                var personel = personelService.GetById(id);
                if (personel == null)
                {
                    Console.WriteLine("Personel bulunamadı.");
                    return;
                }
                if (!SetPersonelBilgileri(personel))
                    return;
                personelService.Update(personel);
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }

        private static void AddNewPersonel()
        {
            try
            {
                Console.WriteLine("Personel girişi yapmak için aşağıdaki alanları giriniz:");
                Console.Write("Id*: ");
                int id = 0;
                if (!Int32.TryParse(Console.ReadLine().Trim(), out id))
                {
                    Console.WriteLine("Id değeri sayısal olmalıdır.");
                    return;
                }
                Personel personel = new Personel();
                personel.Id = id;
                if (!SetPersonelBilgileri(personel))
                    return;
                personelService.Add(personel);
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }

        static bool SetPersonelBilgileri(Personel personel)
        {
            Console.Write("Adı*: ");
            string adi = Console.ReadLine().Trim();
            if (String.IsNullOrWhiteSpace(adi))
            {
                Console.WriteLine("Adı boş olamaz.");
                return false;
            }
            Console.Write("Soyadı*: ");
            string soyadi = Console.ReadLine().Trim();
            if (String.IsNullOrWhiteSpace(soyadi))
            {
                Console.WriteLine("Soyadı boş olamaz.");
                return false;
            }
            Console.Write("Doğum Tarihi (GG.AA.YYYY formatında girilmelidir, boş bırakmak için Enter'a basın): ");
            string tmpDogumTarihi = Console.ReadLine().Trim();
            DateTime tmpTarih;
            DateTime? dogumTarihi = null;
            if (tmpDogumTarihi != "")
            {
                if (!DateTime.TryParse(tmpDogumTarihi, out tmpTarih))
                {
                    Console.WriteLine("Doğum tarihi uygun formatta girilmelidir.");
                    return false;
                }
                else
                {
                    dogumTarihi = tmpTarih;
                }
            }
            Console.Write("Adres: ");
            string adres = Console.ReadLine().Trim();
            Console.Write("Telefon: ");
            string tmpTelefon = Console.ReadLine().Trim();
            long telefon = 0;
            Int64.TryParse(tmpTelefon, out telefon);
            Console.Write("Departman: ");
            string departman = Console.ReadLine().Trim();
            personel.FirstName = adi;
            personel.LastName = soyadi;
            personel.Birthday = dogumTarihi;
            personel.Address = adres;
            personel.Phone = null;
            if (telefon != 0)
                personel.Phone = telefon;
            personel.Department = departman;
            return true;
        }

        private static void DisplayPersonelById()
        {
            try
            {
                Console.WriteLine("Lütfen detayını görmek istediğiniz personelin ID'sini giriniz: ");
                int id = Convert.ToInt32(Console.ReadLine());
                var personel = personelService.GetById(id);
                if (personel != null)
                {
                    Console.WriteLine(personel.Id + "\t" + personel.FirstName + "\t\t" + personel.LastName + "\t\t" + personel.Address + "\t\t" + (personel.Phone ?? 0) + "\t" +
                          (personel.Birthday.HasValue ? personel.Birthday.Value.ToShortDateString() : "\t") + "\t" + personel.Department);
                }
                else
                {
                    Console.WriteLine("Personel bulunamadı.");
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }

        private static void DisplayPersonelList()
        {
            try
            {
                var personeller = personelService.GetList();
                Console.WriteLine("Id\tFirst Name\tLast Name\tAddress\t\t\tPhone\t\tBirthday\tDepartment");
                foreach (var personel in personeller)
                {
                    Console.WriteLine(personel.Id + "\t" + personel.FirstName + "\t\t" + personel.LastName + "\t\t" + personel.Address + "\t\t" + (personel.Phone ?? 0) + "\t" + 
                      (personel.Birthday.HasValue ? personel.Birthday.Value.ToShortDateString() : "\t") + "\t" + personel.Department);
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine("Hata: " + exc.Message);
            }
        }
    }
}
