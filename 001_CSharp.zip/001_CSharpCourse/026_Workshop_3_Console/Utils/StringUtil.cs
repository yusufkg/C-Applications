﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _026_Workshop_3_Console.Utils
{
    static class StringUtil
    {
        public static string[] GetStringArrayBySeperator(string input, char[] seperator)
        {
            return input.Split(seperator);
        }
    }
}
