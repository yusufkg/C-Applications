﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _026_Workshop_3_Console.Data.DegerlendirmeData
{
    class Degerlendirme
    {
        public int Id { get; set; }
        public string Konu { get; set; }
        public string Grup { get; set; }
        public string KisiVeDegerlendirmeler { get; set; }
        public double OrtalamaDegerlendirme { get; set; }
        public DateTime DegerlendirmeTarihi { get; set; }
    }
}
