﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _004_Methods.Extras;

namespace _004_Methods
{
    class Program
    {
        static void Main(string[] args)
        {
            // DRY: Don't repeat yourself
            // CagilAlsac: C büyük, A büyük, yani Pascal case

            #region Methods
            DisplayAdd();
            AddWithoutResult(1, 2);
            var methodResult = AddWithResult(3, 4);
            Console.WriteLine(methodResult);
            Console.WriteLine("PI: " + GetPi());
            int value1 = 4;
            short value2 = 3;
            string resultOfMethod = SubtractWithResult(value1, value2);
            Console.WriteLine(resultOfMethod);
            methodResult = AddWithResultAndDefaultParameters(4);
            Console.WriteLine(methodResult);
            int number1 = 11;
            int number2 = 22;
            methodResult = AddWithResultAndWithoutRefKeyword(number1, number2); // sonuç 33 olması beklenirken 55 dönecek
            Console.WriteLine("Add result: " + methodResult + ", number 1: " + number1); // number1 value type olduğu için 11 olacak
            methodResult = AddWithResultAndWithRefKeyword(ref number1, number2); // sonuç 33 olması beklenirken 55 dönecek
            Console.WriteLine("Add result: " + methodResult + ", number 1: " + number1); // number1 reference type olduğu için 33 olacak
            number1 = 6;
            number2 = 7;
            //int multiplyResult; // ref kullanırken ilk değere assign etmediğimiz için hata verecek
            int multiplyResult = 0;
            methodResult = AddAndMultiplyWithResultAndRefKeyword(6, 7, ref multiplyResult);
            Console.WriteLine("Add result: " + methodResult + ", multiply result: " + multiplyResult);
            int divideResult; // out kullanırken ilk değere assign etmemize gerek yok. bunun dışında ref ile aynı
            methodResult = SubtractAndDivideWithResultAndOutKeyword(20, 10, out divideResult);
            Console.WriteLine("Subtract result: " + methodResult + ", divide result: " + divideResult);
            Console.WriteLine(MultiplyWithResultAndMethodOverload(8, 9));
            Console.WriteLine(MultiplyWithResultAndMethodOverload(8, 9, 10));
            Console.WriteLine(AddWithResultAndParamsKeyword(1, 2, 3, 4, 5)); // overloaded method çalışacak
            #endregion

            #region MethodsDemo
            Console.WriteLine("İşlem giriniz (+, -, *, /, %):");
            string islemInput = Console.ReadLine();
            Console.WriteLine("1. sayıyı giriniz:");
            string sayi1Input = Console.ReadLine();
            Console.WriteLine("2. sayıyı giriniz:");
            string sayi2Input = Console.ReadLine();
            double sayi1 = Convert.ToDouble(sayi1Input);
            double sayi2 = Convert.ToDouble(sayi2Input);
            string islem = islemInput;
            double sonuc = Operation(sayi1, sayi2, islem);
            Console.WriteLine(sayi1 + " " + islem + " " + sayi2 + " = " + sonuc);
            #endregion

            #region Extras
            VucutKutleEndeksi.VucutKutleEndeksiMethod();
            #endregion

            Console.ReadLine();
        }

        #region Methods
        static void DisplayAdd()
        {
            Console.WriteLine("Added!");
        }

        static void AddWithoutResult(int number1, int number2)
        {
            int result = number1 + number2;
            Console.WriteLine(number1 + " + " + number2 + " = " + result);
        }

        static int AddWithResult(int number1, int number2)
        {
            int result = number1 + number2;
            return result;
        }

        static double GetPi()
        {
            return 3.14;
        }

        static string SubtractWithResult(int no1, short no2)
        {
            return "" + (no1 - no2);
        }

        static int AddWithResultAndDefaultParameters(int number1, int number2 = 5) // default değerler her zaman method'un en son parametrelerine verilir. tüm parametrelere default değer atanabilir
        {
            int result = number1 + number2;
            return result;
        }

        static int AddWithResultAndWithoutRefKeyword(int number1, int number2)
        {
            number1 = 33;
            return number1 + number2;
        }

        static int AddWithResultAndWithRefKeyword(ref int number1, int number2)
        {
            number1 = 33;
            return number1 + number2;
        }

        static int AddAndMultiplyWithResultAndRefKeyword(int number1, int number2, ref int multiplyResult)
        {
            multiplyResult = number1 * number2;
            return number1 + number2;
        }

        static int SubtractAndDivideWithResultAndOutKeyword(int number1, int number2, out int divideResult)
        {
            divideResult = number1 / number2;
            return number1 - number2;
        }

        static int MultiplyWithResultAndMethodOverload(int number1, int number2) // int MultiplyWithResultAndMethodOverload(int number1, int number2): methodun imzası
        {
            return number1 * number2;
        }

        static int MultiplyWithResultAndMethodOverload(int number1, int number2, int number3)
        {
            return number1 * number2 * number3;
        }

        static int AddWithResultAndParamsKeyword(params int[] numbers)
        {
            return numbers.Sum();
        }

        static int AddWithResultAndParamsKeyword(int number, params int[] numbers) // params ile belirtilen parametre en sonda olmalıdır
        {
            return number + numbers.Sum();
        }
        #endregion

        #region MethodsDemo
        // Basit bir hesap makinesi:
        static double Operation(double number1, double number2, string _operator)
        {
            double result = 0;
            switch (_operator)
            {
                case "+":
                    result = number1 + number2;
                    break;
                case "-":
                    result = number1 - number2;
                    break;
                case "*":
                    result = number1 * number2;
                    break;
                case "/":
                    result = number1 / number2;
                    break;
                case "%":
                    result = number1 % number2;
                    break;
                // default case'ini yazmadık çünkü işlem +, -, *, / veya % değilse sonucun 0 dönmesini istiyoruz
            }
            return result;
        }
        #endregion
    }
}
