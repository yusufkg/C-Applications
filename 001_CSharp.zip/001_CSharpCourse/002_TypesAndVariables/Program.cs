﻿using _002_TypesAndVariables.Extras;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _002_TypesAndVariables
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            #region Value Types:
            // 1 byte = 8 bits
            #region Integer
            int number1 = 10; // 32 bits. -2 billion to 2 billion (billion: milyar)
            Console.WriteLine("Number 1 is {0}", number1);
            Console.WriteLine("Integer minimum value: " + int.MinValue + ", maximum value: " + int.MaxValue);
            uint number2 = 20; // 32 bits. 0 to 4 billion
            Console.WriteLine("Number 2: " + number2);
            #endregion

            #region Long
            long number3 = 2147483647; // 64 bits. -9 quintillion to 9 quintillion (quintillion: kentilyon)
            number3 = number3 + 1; // maximum integer value + 1
            Console.WriteLine("Number 3 is " + number3);
            ulong number4 = 40; // 64 bits. 0 to 18 quintillion
            Console.WriteLine("Number 4: " + number4);
            #endregion

            #region Short
            short number5 = -19; // 16 bits. -32,768 to 32,767
            Console.WriteLine("Number 5: " + number5);
            ushort number6 = 19; // 16 bits. 0 to 65,535
            Console.WriteLine("Number 6: " + number6);
            #endregion

            #region Byte
            byte number7 = 255; // 8 bits. 0 to 255
            Console.WriteLine("Number 7: " + number7);
            sbyte number8 = -128; // 8 bits. -128 to 127
            Console.WriteLine("Number 8: " + number8);
            #endregion

            #region Boolean
            bool condition = true; // 1 bit (1 byte in C#). 1 or 0
            Console.WriteLine("Condition: " + condition);
            #endregion

            #region Char
            char character = 'A'; // ASCII characters (8 bits), Unicode characters (16 bits) in C#
            Console.WriteLine("Character is: " + character + ", ASCII code is: " + (int)character);
            #endregion

            #region Double
            double number9 = 1.7; // 64 bits. 15 significant digits. For the double datatype, positive values are 4.9 x 10^-324 to 1.8 x 10^308. Negative values are -1.8 x 10^308 to -4.9 x 10^-324
            Console.WriteLine("Number 9: " + number9);
            #endregion

            #region Float
            float number10 = -12.34567F; // 32 bits. 7 significant digits. For the float datatype, positive values are 1.4 x 10^-45 to 3.4 x 10^38. Negative values are -3.4 x 10^38 to -1.4 x 10^-45
            Console.WriteLine("Number 10 is: " + number10 + ", minimum value: " + float.MinValue + ", maximum value: " + float.MaxValue);
            #endregion

            #region Decimal
            decimal number11 = 11.77M; // 24 * 8 bits. 28 to 29 significant digits. For the decimal datatype, positive values are 1.0 x 10^-28 to 7.9 x 10^28. Negative values are -7.9 x 10^28 to -1.0 x 10^-28
            Console.WriteLine("Number 11: " + number11);
            #endregion

            #region Enum
            Console.WriteLine(Days.Monday);
            #endregion
            #endregion

            #region Reference Type:
            #region String
            string characters = "Ankara"; // 4 byte address. Length up to 2 billion bytes. A string variable in C# cannot be declared as fixed length. Array of characters
            Console.WriteLine("String is: " + characters);
            #endregion
            #endregion

            #region Var
            var number12 = 123;
            Console.WriteLine("Number 12 is: " + number12);
            number12 = 'A';
            Console.WriteLine("New number 12 is: " + number12);
            #endregion

            #region Extras
            DataTipleri.DataTipleriMethod();
            #endregion

            Console.ReadLine();
        }
    }

    #region Enum
    enum Days
    {
        Monday, // value: 0
        Tuesday, // value: 1
        Wednesday, // value: 2
        Thursday, // value: 3
        Friday, // value: 4
        Saturday, // value: 5
        Sunday // value: 6
    }
    enum ModifiedDays1
    {
        Monday = 1, // value: 1
        Tuesday, // value: 2
        Wednesday, // value: 3
        Thursday, // value: 4
        Friday, // value: 5
        Saturday, // value: 6
        Sunday // value: 7
    }
    enum ModifiedDays2
    {
        Monday = 11, // value: 11
        Tuesday = 22, // value: 22
        Wednesday = 33, // value: 33
        Thursday = 44, // value: 44
        Friday = 55, // value: 55
        Saturday = 66, // value: 66
        Sunday = 77 // value: 77
    }
    #endregion
}
