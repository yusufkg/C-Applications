﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _002_TypesAndVariables.Extras
{
    class DataTipleri
    {
        public static void DataTipleriMethod()
        {
            #region Tam sayı tipleri
            int sayi1 = 12; // Hafızada 2^32 bit yer ayrılır. Int32
            sayi1 = 44;
            Console.WriteLine(sayi1);
            Console.WriteLine(int.MaxValue);
            Console.WriteLine(int.MinValue);
            Console.WriteLine(uint.MaxValue); // İşaretsiz integer (Unsigned integer).
            Console.WriteLine(uint.MinValue);

            short sayi2 = 2; // Hafızada 2^16 bitlik yer tutar. Int16
            Console.WriteLine(sayi2);
            Console.WriteLine(short.MaxValue);
            Console.WriteLine(short.MinValue);
            Console.WriteLine(ushort.MaxValue); // İşaretsiz short (Unsigned short).
            Console.WriteLine(ushort.MinValue);

            byte sayi3 = 5; // Hafızada 2^8 bitlik yer tutar.
            Console.WriteLine(sayi3);
            Console.WriteLine(byte.MaxValue);
            Console.WriteLine(byte.MinValue);
            Console.WriteLine(sbyte.MaxValue); // İşaretli byte (Signed byte).
            Console.WriteLine(sbyte.MinValue);

            long sayi4 = 3; // Hafızada 2^64 bitlik yer tutar. Int64
            Console.WriteLine(sayi4);
            Console.WriteLine(long.MaxValue);
            Console.WriteLine(long.MinValue);
            Console.WriteLine(ulong.MaxValue); // İşaretsiz long (Unsigned long).
            Console.WriteLine(ulong.MinValue);
            #endregion

            #region Ondalık sayı tipleri
            double sayi5 = 6.01; // Hafızada 2^64 bitlik yer tutar.
            Console.WriteLine(sayi5);
            Console.WriteLine(double.MaxValue);
            Console.WriteLine(double.MinValue);

            float sayi6 = 16.7f; // Hafızada 2^32 bitlik yer tutar.
            Console.WriteLine(sayi6);
            Console.WriteLine(float.MaxValue);
            Console.WriteLine(float.MinValue);

            decimal sayi7 = 12.4m; // Hafızada 2^128 bitlik yer tutar.
            Console.WriteLine(sayi7);
            Console.WriteLine(decimal.MaxValue);
            Console.WriteLine(decimal.MinValue);
            #endregion

            #region Metinsel tipler
            char karakter1 = 'Ç'; // Yalnızca tek karakter yazılır.
            Console.WriteLine(karakter1);

            Char karakter2 = 'A';
            Console.WriteLine(karakter2);

            string text1 = "\"Çağıl\""; // Hafızada ne kadar yer tutar gibi bir ölçü birimi yoktur. String bir char dizisidir.
            Console.WriteLine(text1);

            String text2 = @"\Alsaç\";
            Console.WriteLine(text2);
            /* Özel karakterler: (\ ile kullanılır)
             * \" - Çift tırnak
             * \n - New line (Alt satır)
             * \r - Carriage return (Satır başı)
             * \\ - Slash
             * \t - Tab
            */
            #endregion

            #region Mantıksal tip (Doğruluk tipi)
            bool deger1 = true;
            Console.WriteLine(deger1);

            Boolean deger2 = false;
            Console.WriteLine(deger2);
            //Console.ReadLine();
            #endregion
        }
    }
}
