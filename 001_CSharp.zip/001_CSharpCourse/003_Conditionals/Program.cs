﻿using _003_Conditionals.Extras;
using System;

namespace _003_Conditionals
{
    class Program
    {
        static void Main(string[] args)
        {
            // Logical operators: && (and), || (or), ! (not)
            // Relational operators: ==, !=, >=, <=, >, <
            // Arithmetic operators: +, -, *, /, %
            // Assignment operator: =

            #region Logical Operators
            /* Önermeler:
             * p    q       ve
             * ---------------
             * 0    0       0
             * 0    1       0
             * 1    0       0
             * 1    1       1
             * 
             * p    q     veya
             * ---------------
             * 0    0       0
             * 0    1       1
             * 1    0       1
             * 1    1       1
            */
            Console.WriteLine("*** Logical Operators ***");
            bool p, q, result;
            p = true;
            q = true;
            result = p && q;
            Console.WriteLine("p: " + p + " && (and) q: " + q + " = " + result);
            result = p || q;
            Console.WriteLine("p: " + p + " || (or) q: " + q + " = " + result);
            p = false;
            q = true;
            result = p && q;
            Console.WriteLine("p: " + p + " && (and) q: " + q + " = " + result);
            result = p || q;
            Console.WriteLine("p: " + p + " || (or) q: " + q + " = " + result);
            p = true;
            q = false;
            result = p && q;
            Console.WriteLine("p: " + p + " && (and) q: " + q + " = " + result);
            result = p || q;
            Console.WriteLine("p: " + p + " || (or) q: " + q + " = " + result);
            p = false;
            q = false;
            result = p && q;
            Console.WriteLine("p: " + p + " && (and) q: " + q + " = " + result);
            result = p || q;
            Console.WriteLine("p: " + p + " || (or) q: " + q + " = " + result);
            #endregion

            #region Conditionals
            var number = 10;
            if (number == 10)
            {
                Console.WriteLine("Number is 10");
            }
            else
            {
                Console.WriteLine("Number is not 10");
            }

            number = 11;
            Console.WriteLine(number == 10 ? "Number is 10" : "Number is not 10");

            number = 20;
            if (number == 10)
            {
                Console.WriteLine("Number is 10");
            }
            else if (number == 20)
            {
                Console.WriteLine("Number is 20");
            }
            else
            {
                Console.WriteLine("Number is not 10 or 20");
            }

            switch (number)
            {
                case 10:
                    Console.WriteLine("Number is 10");
                    break;
                case 20:
                    Console.WriteLine("Number is 20");
                    break;
                default:
                    Console.WriteLine("Number is not 10 or 20");
                    break;
            }
            #endregion

            #region Demo1
            // 0 ile 200 arasında bir sayı:
            number = 11;
            if (number >= 0 && number <= 100)
            {
                Console.WriteLine("Number is between 0 - 100");
            }
            else if (number > 100 && number <= 200)
            {
                Console.WriteLine("Number is between 100 - 200");
            }
            else if (number > 200 || number < 0) // bu condition olmadan, yani sadece else ile de aynı sonucu verir
            {
                Console.WriteLine("Number is out of range");
            }
            #endregion

            #region Demo2
            // Sayı pozitif mi negatif mi kontrolü (İç içe if blokları):
            Console.WriteLine("Bir sayı girin:");
            int demoNumber = Convert.ToInt32(Console.ReadLine());
            if (demoNumber == 0)
            {
                Console.WriteLine("Sayı sıfıra eşit");
            }
            else
            {
                if (demoNumber > 0)
                    Console.WriteLine("Sayı pozitif");
                else
                    Console.WriteLine("Sayı negatif");
            }
            #endregion

            #region Demo3
            Console.Write("Yazı (y) mı tura (t) mı? ");
            string input = Console.ReadLine();
            if (input == "t")
                number = 1; // tura
            else
                number = 0; // yazı
            Random random = new Random();
            int randomNumber = random.Next(0, 2); // 2 dahil değil, 0 veya 1 döner sadece. tura 1 yazı 0 olsun
            if (number == randomNumber)
                Console.WriteLine(number == 1 ? "Tura geldi, bildiniz." : "Yazı geldi, bildiniz.");
            else
                Console.WriteLine(randomNumber == 1 ? "Tura geldi, bilemediniz." : "Yazı geldi, bilemediniz.");
            #endregion

            #region Unnecessary If Usage
            Console.Write("Enter the day of week as number (1: Monday, 2: Tuesday, 3: Wednesday, 4: Thursday, 5: Friday, 6: Saturday, 7: Sunday)...");
            input = Console.ReadLine();
            int day = Convert.ToInt32(input);
            if (day == 1)
                Console.WriteLine("You entered Monday");
            else if (day == 2)
                Console.WriteLine("You entered Tuesday");
            else if (day == 3)
                Console.WriteLine("You entered Wednesday");
            else if (day == 4)
                Console.WriteLine("You entered Thursday");
            else if (day == 5)
                Console.WriteLine("You entered Friday");
            else if (day == 6)
                Console.WriteLine("You entered Saturday");
            else
                Console.WriteLine("You entered Sunday");

            Console.Write("Enter the day of week as number (1: Monday, 2: Tuesday, 3: Wednesday, 4: Thursday, 5: Friday, 6: Saturday, 7: Sunday)...");
            input = Console.ReadLine();
            day = Convert.ToInt32(input);
            Console.WriteLine(Enum.GetName(typeof(Days), day));
            #endregion

            #region Effective If Usage

            // Ineffective way:
            Console.Write("Para birimi giriniz (TL, AUD, CAD, NZD, JPY, CHF, GBP, EUR, USD): ");
            input = Console.ReadLine();
            if (input == "AUD")
                Console.WriteLine("Avusturalya Doları (AUD)");
            else if (input == "CAD")
                Console.WriteLine("Kanada Doları (CAD)");
            else if (input == "NZD")
                Console.WriteLine("Yeni Zelanda Doları (NZD)");
            else if (input == "JPY")
                Console.WriteLine("Japon Yeni (JPY)");
            else if (input == "CHF")
                Console.WriteLine("İsviçre Frangı (CHF)");
            else if (input == "GBP")
                Console.WriteLine("İngiliz Sterlini (GBP)");
            else if (input == "EUR")
                Console.WriteLine("Euro (EUR)");
            else if (input == "USD")
                Console.WriteLine("Amerikan Doları (USD)");
            else if (input == "TL")
                Console.WriteLine("Türk Lirası (TL)");
            else
                Console.WriteLine("Giriş uygun değil!");

            // Effective way 1:
            Console.Write("Para birimi giriniz (TL, AUD, CAD, NZD, JPY, CHF, GBP, EUR, USD): ");
            input = Console.ReadLine();
            if (input == "TL") // Türkiye'de olduğumuzdan en çok TL girilecektir tahmininde bulunuyoruz. Bu şekilde TL'yi ilk sıraya taşıyarak performans kazanmış olduk
                Console.WriteLine("Türk Lirası (TL)");
            else if (input == "AUD")
                Console.WriteLine("Avusturalya Doları (AUD)");
            else if (input == "CAD")
                Console.WriteLine("Kanada Doları (CAD)");
            else if (input == "NZD")
                Console.WriteLine("Yeni Zelanda Doları (NZD)");
            else if (input == "JPY")
                Console.WriteLine("Japon Yeni (JPY)");
            else if (input == "CHF")
                Console.WriteLine("İsviçre Frangı (CHF)");
            else if (input == "GBP")
                Console.WriteLine("İngiliz Sterlini (GBP)");
            else if (input == "EUR")
                Console.WriteLine("Euro (EUR)");
            else if (input == "USD")
                Console.WriteLine("Amerikan Doları (USD)");
            else
                Console.WriteLine("Giriş uygun değil!");

            // Effective way 2:
            Console.Write("Para birimi giriniz (TL, AUD, CAD, NZD, JPY, CHF, GBP, EUR, USD): ");
            input = Console.ReadLine();
            //if (input != "TL" && input != "AUD" && input != "CAD" && input != "NZD" && input != "JPY" &&
            //    input != "CHF" && input != "GBP" && input != "EUR" && input != "USD") // aşağıyla aynı condition
            if (!(input == "TL" || input == "AUD" || input == "CAD" || input == "NZD" || input == "JPY" ||
                input == "CHF" || input == "GBP" || input == "EUR" || input == "USD"))
            {
                Console.WriteLine("Giriş uygun değil!"); // giriş zor olduğundan sık sık yanlış girilebilir tahmininde bulunuyoruz. Giriş hatalıysa para birimi kontrollerine gerek yok
            }
            else
            {
                if (input == "TL") // Türkiye'de olduğumuzdan en çok TL girilecektir tahmininde bulunuyoruz. Bu şekilde TL'yi ilk sıraya taşıyarak performans kazanmış olduk
                    Console.WriteLine("Türk Lirası (TL)");
                else if (input == "AUD")
                    Console.WriteLine("Avusturalya Doları (AUD)");
                else if (input == "CAD")
                    Console.WriteLine("Kanada Doları (CAD)");
                else if (input == "NZD")
                    Console.WriteLine("Yeni Zelanda Doları (NZD)");
                else if (input == "JPY")
                    Console.WriteLine("Japon Yeni (JPY)");
                else if (input == "CHF")
                    Console.WriteLine("İsviçre Frangı (CHF)");
                else if (input == "GBP")
                    Console.WriteLine("İngiliz Sterlini (GBP)");
                else if (input == "EUR")
                    Console.WriteLine("Euro (EUR)");
                else // if (input == "USD")
                    Console.WriteLine("Amerikan Doları (USD)");
            }

            // Effective way 3:
            Console.Write("Para birimi giriniz (TL, AUD, CAD, NZD, JPY, CHF, GBP, EUR, USD): ");
            input = Console.ReadLine();
            if (input != "TL" && input != "AUD" && input != "CAD" && input != "NZD" && input != "JPY" &&
                input != "CHF" && input != "GBP" && input != "EUR" && input != "USD")
            //if (!(input == "TL" || input == "AUD" || input == "CAD" || input == "NZD" || input == "JPY" ||
            //      input == "CHF" || input == "GBP" || input == "EUR" || input == "USD")) // yukarıyla aynı condition
            {
                return; // giriş zor olduğundan sık sık yanlış girilebilir tahmininde bulunuyoruz. Giriş hatalıysa para birimi kontrollerine gerek yok. Main method'undan dolayısıyla programdan çık
            }
            // giriş uygunsa kod çalışmaya ve if else kontrollerine girmeye devam edecektir
            if (input == "TL") // Türkiye'de olduğumuzdan en çok TL girilecektir tahmininde bulunuyoruz. Bu şekilde TL'yi ilk sıraya taşıyarak performans kazanmış olduk
                Console.WriteLine("Türk Lirası (TL)");
            else if (input == "AUD")
                Console.WriteLine("Avusturalya Doları (AUD)");
            else if (input == "CAD")
                Console.WriteLine("Kanada Doları (CAD)");
            else if (input == "NZD")
                Console.WriteLine("Yeni Zelanda Doları (NZD)");
            else if (input == "JPY")
                Console.WriteLine("Japon Yeni (JPY)");
            else if (input == "CHF")
                Console.WriteLine("İsviçre Frangı (CHF)");
            else if (input == "GBP")
                Console.WriteLine("İngiliz Sterlini (GBP)");
            else if (input == "EUR")
                Console.WriteLine("Euro (EUR)");
            else // if (input == "USD") // else sadece USD koşulu olduğundan açıklayıcı olsun diye comment içinde if koşulunu yazdık
                Console.WriteLine("Amerikan Doları (USD)");

            #endregion region

            #region Extras
            OgrenciNotOrtalamasi.OgrenciNotOrtalamasiMethod();
            HaftaninGunleri.HaftaninGunleriMethod();
            HesapMakinesi.HesapMakinesiMethod();
            KoronavirusTespit.KoronavirusBelirtiMethod();
            KoronavirusTespit.KoronavirusYuzdeMethod();
            KullaniciGirisi.KullaniciGirisiMethod();
            SayiKarsilastirma.IkiSayiKarsilastirmaMethod();
            SayiKarsilastirma.UcSayiKarsilastirmaMethod();
            EhliyetAlabilme.EhliyetAlabilmeMethod();
            AyaGoreMevsim.AyaGoreMevsimMethod();
            PlakaVeSehirler.PlakaVeSehirlerMethod();
            TlDovizHesaplama.TlDovizHesaplamaMethod();
            #endregion

            Console.ReadLine();
        }

        #region Unnecessary If Usage
        enum Days
        {
            Monday = 1,
            Tuesday = 2,
            Wednesday = 3,
            Thursday = 4,
            Friday = 5,
            Saturday = 6,
            Sunday = 7
        }
        #endregion
    }
}
