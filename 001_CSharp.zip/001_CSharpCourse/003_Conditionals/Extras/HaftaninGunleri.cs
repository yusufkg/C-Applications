﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _003_Conditionals.Extras
{
    class HaftaninGunleri
    {
        public static void HaftaninGunleriMethod()
        {
            Console.Write("Sayı girin (1 - 7): ");
            string s = Console.ReadLine();
            switch (s)
            {
                case "1":
                    Console.WriteLine("P.tesi");
                    break;
                case "2":
                    Console.WriteLine("Salı");
                    break;
                case "3":
                    Console.WriteLine("Çarşamba");
                    break;
                case "4":
                    Console.WriteLine("Perşembe");
                    break;
                case "5":
                    Console.WriteLine("Cuma");
                    break;
                case "6":
                    Console.WriteLine("C.tesi");
                    break;
                case "7":
                    Console.WriteLine("Pazar");
                    break;
                default:
                    Console.WriteLine("HATA!");
                    break;
            }
            // break içinde bulunduğu scope'dan bizi dışarı atar!
            //Console.ReadLine();
        }
    }
}
