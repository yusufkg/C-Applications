﻿using System;

namespace _009_Workshop_1.Extras
{
    class TypesVariablesConditionalsMethodsLoops
    {
        #region Global Variables
        static string globalDegisken = "Global Değer"; // bu sınıf için global variable
        #endregion

        public static void TypesVariablesConditionalsMethodsLoopsMethod()
        {
            #region Variables
            var hamburger = "Whopper";
            var icecek = "Kola";
            Console.WriteLine(hamburger);
            Console.WriteLine(hamburger.GetType());
            Console.WriteLine(icecek);
            Console.WriteLine(hamburger + " " + icecek);
            var aboneMi = false;
            Console.WriteLine(aboneMi);
            Console.WriteLine(aboneMi.GetType());
            #endregion

            #region Functions
            var sayi1 = 6;
            var sayi2 = 16;
            var sayi3 = 3;
            var sayi4 = 48;
            var sayi5 = 49;
            var sayi6 = 11;
            Console.WriteLine("Kolon: " + sayi1 + " " + sayi2 + " " + sayi3 + " " + sayi4 + " " + sayi5 + " " + sayi6);
            var rasgele = new Random();
            var rasgeleSayi1 = rasgele.Next(1, 49);
            var rasgeleSayi2 = rasgele.Next(1, 49);
            var rasgeleSayi3 = rasgele.Next(1, 49);
            var rasgeleSayi4 = rasgele.Next(1, 49);
            var rasgeleSayi5 = rasgele.Next(1, 49);
            var rasgeleSayi6 = rasgele.Next(1, 49);
            Console.WriteLine("Kolon: " + rasgeleSayi1 + " " + rasgeleSayi2 + " " + rasgeleSayi3 + " " + rasgeleSayi4 + " " + rasgeleSayi5 + " " + rasgeleSayi6);
            var rasgeleUretilenSayi1 = RasgeleSayiUret1();
            var rasgeleUretilenSayi2 = RasgeleSayiUret1();
            var rasgeleUretilenSayi3 = RasgeleSayiUret1();
            var rasgeleUretilenSayi4 = RasgeleSayiUret1();
            var rasgeleUretilenSayi5 = RasgeleSayiUret1();
            var rasgeleUretilenSayi6 = RasgeleSayiUret1();
            Console.WriteLine("Kolon: " + rasgeleUretilenSayi1 + " " + rasgeleUretilenSayi2 + " " + rasgeleUretilenSayi3 + " " + rasgeleUretilenSayi4 + " " + rasgeleUretilenSayi5 + " " + rasgeleUretilenSayi6);
            rasgeleUretilenSayi1 = RasgeleSayiUret2(rasgele);
            rasgeleUretilenSayi2 = RasgeleSayiUret2(rasgele);
            rasgeleUretilenSayi3 = RasgeleSayiUret2(rasgele);
            rasgeleUretilenSayi4 = RasgeleSayiUret2(rasgele);
            rasgeleUretilenSayi5 = RasgeleSayiUret2(rasgele);
            rasgeleUretilenSayi6 = RasgeleSayiUret2(rasgele);
            Console.WriteLine("Kolon: " + rasgeleUretilenSayi1 + " " + rasgeleUretilenSayi2 + " " + rasgeleUretilenSayi3 + " " + rasgeleUretilenSayi4 + " " + rasgeleUretilenSayi5 + " " + rasgeleUretilenSayi6);
            rasgeleUretilenSayi1 = RasgeleSayiUret2(rasgele, 1);
            rasgeleUretilenSayi2 = RasgeleSayiUret2(rasgele, 1);
            rasgeleUretilenSayi3 = RasgeleSayiUret2(rasgele, 1);
            rasgeleUretilenSayi4 = RasgeleSayiUret2(rasgele, 1);
            rasgeleUretilenSayi5 = RasgeleSayiUret2(rasgele, 1);
            rasgeleUretilenSayi6 = RasgeleSayiUret2(rasgele, 1);
            Console.WriteLine("Kolon: " + rasgeleUretilenSayi1 + " " + rasgeleUretilenSayi2 + " " + rasgeleUretilenSayi3 + " " + rasgeleUretilenSayi4 + " " + rasgeleUretilenSayi5 + " " + rasgeleUretilenSayi6);
            #endregion

            #region Global Variables
            Console.WriteLine(globalDegisken);
            #endregion

            #region Conditionals
            var not = 21;
            // not 50'den büyük ise
            if (not > 50)
            {
                Console.WriteLine("Geçtiniz");
            }
            else if (not >= 40) // not 50'den küçük veya eşit, 40'dan büyük veya eşit ise
            {
                Console.WriteLine("Bütünlemeye kaldınız");
            }
            else // not 40'dan küçük ise
            {
                Console.WriteLine("Kaldınız");
            }
            // 3 sayıdan en büyüğünü bulma:
            var no1 = 3;
            var no2 = 5;
            var no3 = 1;
            var enBuyukNo = no1;
            if (no2 > no1)
                enBuyukNo = no2;
            if (no3 > enBuyukNo)
                enBuyukNo = no3;
            Console.WriteLine("En büyük sayı: " + enBuyukNo);
            // 3 sayı birbirine eşit mi:
            no1 = 10;
            no2 = 10;
            no3 = 10;
            if (no1 == no2 && no2 == no3)
                Console.WriteLine("Sayılar eşit");
            // 3 sayıdan en az ikisi birbirine eşit mi:
            no1 = 10;
            no2 = 20;
            no3 = 10;
            if (no1 == no2 || no2 == no3 || no1 == no3)
                Console.WriteLine("En az iki sayı eşit");
            #endregion

            #region Loops
            // 0 ile 10 arasındaki çift sayılar:
            var sayi = 0;
            while (sayi <= 10)
            {
                Console.WriteLine(sayi);
                sayi = sayi + 2;
            }
            sayi = 0;
            do
            {
                Console.WriteLine(sayi);
                sayi += 2;
            } while (sayi <= 10);
            // 1 ile 9 arasındaki çift sayılar:
            for (var i = 1; i <= 9; i += 2)
            {
                Console.WriteLine(i);
            }
            // Sayısal Loto 8 kolon için rasgele 6 sayı:
            for (var i = 1; i <= 8; i++)
            {
                Console.WriteLine(i + ". Kolon:");
                for (var j = 1; j <= 6; j++)
                {
                    Console.WriteLine(RasgeleSayiUret2(rasgele, 1, 49));
                }
            }
            #endregion

            //Console.ReadLine();
        }

        #region Functions
        static int RasgeleSayiUret1() // doğru çalışmayacak, hep aynı sayıyı döndürecek
        {
            var rasgele = new Random();
            return rasgele.Next(1, 49);
        }
        static int RasgeleSayiUret2(Random rasgele) // doğru çalışması için rasgele parametresini gönderiyoruz
        {
            return rasgele.Next(1, 49);
        }
        static int RasgeleSayiUret2(Random rasgele, int altLimit, int ustLimit = 49) // method overloading. default parameter ustLimit = 49
        {
            return rasgele.Next(altLimit, ustLimit);
        }
        #endregion
    }
}
