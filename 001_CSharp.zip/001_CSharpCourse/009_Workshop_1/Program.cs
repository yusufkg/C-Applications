﻿using _009_Workshop_1.Extras;
using System;

namespace _009_Workshop_1
{
    class Program
    {
        static void Main(string[] args)
        {
            DamaTahtasi damaTahtasi = new DamaTahtasi();
            damaTahtasi.Goster();

            #region Types, Variables, Conditionals, Methods and Loops Demo
            TypesVariablesConditionalsMethodsLoops.TypesVariablesConditionalsMethodsLoopsMethod();
            #endregion

            Console.ReadLine();
        }
    }
}
