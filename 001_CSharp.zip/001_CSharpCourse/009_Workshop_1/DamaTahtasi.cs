﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _009_Workshop_1
{
    class DamaTahtasi
    {
        public void Goster()
        {
            string tahta = Olustur();
            Console.WriteLine(tahta);
        }

        public string Olustur()
        {
            string kareler = "";
            string kare;
            bool black;
            for (int i = 1; i <= 8; i++)
            {
                if (i % 2 == 0)
                    black = false;
                else
                    black = true;
                for (int j = 1; j <= 8; j++)
                {
                    kare = "-";
                    if (black)
                        kare = "*";
                    kareler += kare;
                    black = !black;
                }
                kareler += "\n";
            }
            return kareler.Trim(new char[] { '\n' });
        }
    }
}
