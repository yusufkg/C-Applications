﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _025_Exceptions
{
    class RecordNotFoundException : Exception
    {
        public RecordNotFoundException(string message = "Record not found!") : base(message)
        {
            
        }
    }
}
