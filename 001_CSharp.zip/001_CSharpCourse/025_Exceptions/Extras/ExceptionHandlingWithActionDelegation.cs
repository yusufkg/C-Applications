﻿using System;

namespace _025_Exceptions.Extras
{
    class ExceptionHandlingWithActionDelegation
    {
        public static void ExceptionHandlingWithActionDelegationMethod()
        {
            HandleException(() =>
            {
                Program.FindRecord2(); // Program.cs'de FindRecord2() methodunu yazdığımız için bu methodun erişimini public yapıp tekrar aynısını burada yazmadan methoda erişebiliriz.
                                       // method yerine herhangi bir kod bloğu da yazılabilir
            }); // methodu parametre olarak gönderiyoruz. C#'a özel bir kullanım
            // (): parametresiz bir method (kod bloğu göndereceğim)
            // => lambda
            // {}: kod kümemiz
        }

        private static void HandleException(Action action) // Action: parametresiz bir method olarak düşünülebilir. void operasyonlar için kullanılır
        {
            try
            {
                action.Invoke();
            }
            catch (Exception e)
            {
                Console.WriteLine("Action Delegasyonu ile yakaladığımız hata: " + e.Message);
            }
        }
    }
}
