﻿using _025_Exceptions.Extras;
using System;
using System.Collections.Generic;
using System.IO;

namespace _025_Exceptions
{
    class Program
    {
        // hatalar uygulama güvenlikleri ile ilgili sorunlar çıkarabilir. dikkat edilmezse hatalar sayesinde uygulamanın içeriğiyle ilgili bilgi alınabilir.
        static void Main(string[] args)
        {
            #region Exceptions Intro
            Console.WriteLine("Program başladı.");
            try
            {
                string[] students = new string[3];
                students[0] = "Çağıl";
                students[1] = "Angel";
                students[2] = "Leo";
                students[3] = "Ahmet"; // hata verecektir çünkü array 3 elemanlı
            }
            catch
            {
                Console.WriteLine("Hata meydana geldi!");
            }

            try
            {
                int number1 = 13;
                int number2 = 0;
                int result = number1 / number2; // hata verecektir çünkü herhangi bir sayının 0'a bölümü tanımsızdır
                Console.WriteLine(number1 + " / " + number2 + " = " + result);
            }
            catch (Exception e)
            {
                Console.WriteLine("Hata meydana geldi: " + e.Message); // e.Message son kullanıcıya gösterilmez.
                                                                       // mesela veritabanına bağlantı sırasında hata alındığında tüm veritabanı bağlantı bilgileri e.Message ile ekrana gelebilir
                                                                       // e.Message gibi hata mesajlarını loglamayı tercih ederiz
                //Console.WriteLine("Hata meydana geldi: " + e.InnerException.Message); // e.InnerException null değilse bize hata hakkında daha detaylı bilgi verir 
            }

            try
            {
                string[] students = new string[3];
                students[0] = "Çağıl";
                students[1] = "Angel";
                students[2] = "Leo";
                students[3] = "Ahmet"; // hata verecektir çünkü array 3 elemanlı
            }
            catch (IndexOutOfRangeException e) // catch içerisinde hatanın türüne de bakılabilir
            {
                Console.WriteLine("Hata meydana geldi: " + e.Message);
            }

            try
            {
                string filePath = @"C:\students.txt";
                string fileContent = File.ReadAllText(filePath);
                Console.WriteLine("students.txt content: " + fileContent);
            }
            catch (IndexOutOfRangeException e) // catch içerisinde hatanın türüne de bakılabilir. eğer hata IndexOutOfRangeException tipinde değilse bir aşağıdaki catch bloğu çalışır
            {
                Console.WriteLine("Index Out Of Range Hatası meydana geldi: " + e.Message);
            }
            catch (DivideByZeroException e) // eğer hata DivideByZeroException tipinde değilse bir aşağıdaki catch bloğu çalışır
            {
                Console.WriteLine("Divide By Zero Hatası meydana geldi: " + e.Message);
            }
            catch (FileNotFoundException e) // eğer hata FileNotFoundException tipinde değilse bir aşağıdaki catch bloğu çalışır
            {
                Console.WriteLine("File Not Found Hatası meydana geldi: " + e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Genel Hata meydana geldi: " + e.Message);
            }

            try
            {
                string[] students = new string[3];
                students[0] = "Çağıl";
                students[1] = "Angel";
                students[2] = "Leo";
                students[3] = "Ahmet"; // hata verecektir çünkü array 3 elemanlı
                Console.WriteLine("Try bloğu çalıştı.");
            }
            catch (Exception e)
            {
                Console.WriteLine("Catch bloğu çalıştı.");
            }
            finally // try da çalışsa, catch de çalışsa en sonunda mutlaka finally çalışır. yazmak zorunlu değil
            {
                Console.WriteLine("Finally bloğu çalıştı.");
            }
            Console.WriteLine("Program bitti.");
            #endregion

            #region Kendi Exception Class'ımız
            // RecordNotFoundException class'ımızı yazalım:
            try
            {
                FindRecord1();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            try
            {
                FindRecord2();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            #endregion

            #region Action Delegation
            ExceptionHandlingWithActionDelegation.ExceptionHandlingWithActionDelegationMethod();
            #endregion

            Console.ReadLine();
        }

        #region Kendi Exception Class'ımız
        private static void FindRecord1()
        {
            List<string> students = new List<string>()
            {
                "Çağıl",
                "Angel",
                "Leo"
            };
            if (students.Contains("Muhittin"))
                Console.WriteLine("Record found.");
            else
                throw new RecordNotFoundException();
        }

        public static void FindRecord2()
        {
            List<string> students = new List<string>()
            {
                "Çağıl",
                "Angel",
                "Leo"
            };
            if (students.Contains("Muhittin"))
                Console.WriteLine("Record found.");
            else
                throw new RecordNotFoundException("Kayıt bulunamadı!");
        }
        #endregion
    }
}
