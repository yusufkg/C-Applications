﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _015_Workshop_2
{
    // loglama örneği:
    class Program
    {
        static void Main(string[] args)
        {
            #region Yanlış Yöntem
            CustomerManager_Wrong customerManager_wrong = new CustomerManager_Wrong();
            customerManager_wrong.Add();
            #endregion

            #region Doğru Yöntem
            CustomerManager_Correct customerManager_correct1 = new CustomerManager_Correct() { Logger = new LoggerDatabase_Correct() }; // property injection
            customerManager_correct1.Add();

            CustomerManager_Correct customerManager_correct2 = new CustomerManager_Correct() { Logger = new LoggerFile_Correct() }; // property injection
            customerManager_correct2.Add();

            CustomerManager_Correct customerManager_correct3 = new CustomerManager_Correct();
            customerManager_correct3.Add();
            #endregion

            Console.ReadLine();
        }
    }

    #region Yanlış Yöntem
    class CustomerManager_Wrong
    {
        public void Add()
        {
            Logger_Wrong logger = new Logger_Wrong();
            logger.Log();
            Console.WriteLine("Customer added");
        }
    }

    class Logger_Wrong // bir class böyle çıplak yani herhangi bir interface'i ya da base'i yoksa bu class'tan korkulmalı. çünkü mecburen new'leyerek kullanabiliriz sadece.
                       // yarın öbür gün yeni bir log'lamaya ihtiyacımız olursa bu class'ın içindeki method'ların tümünü veya bir kısmını değiştirmemiz gerekecek.
                       // mesela metin dosyasına log'lama istenebilir
    {
        public void Log()
        {
            Console.WriteLine("Logged to database");
        }
    }
    #endregion

    #region Doğru Yöntem
    class CustomerManager_Correct
    {
        public ILogger Logger { get; set; } = new LoggerSms_Correct(); // property injection
        public void Add()
        {
            Logger.Log();
            Console.WriteLine("Customer added");
        }
    }

    interface ILogger
    {
        void Log();
    }

    class LoggerDatabase_Correct : ILogger // database logger
    {
        public void Log()
        {
            Console.WriteLine("Logged to database");
        }
    }

    class LoggerFile_Correct : ILogger // file logger
    {
        public void Log()
        {
            Console.WriteLine("Logged to file");
        }
    }

    class LoggerSms_Correct : ILogger // SMS logger
    {
        public void Log()
        {
            Console.WriteLine("Logged to SMS");
        }
    }
    #endregion
}
