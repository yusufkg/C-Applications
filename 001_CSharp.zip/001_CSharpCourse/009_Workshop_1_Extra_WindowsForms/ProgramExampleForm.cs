﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _009_Workshop_1_Extra_WindowsForms
{
    public partial class ProgramExampleForm : Form
    {
        public ProgramExampleForm() // constructor, daha sonra bahsedilecek
        {
            InitializeComponent();
        }

        private void ProgramExample_Load(object sender, EventArgs e)
        {
            InitializeForm();
            PopulateButtons1(); // 1. yol
            //PopulateButtons2(); // 2. yol
        }

        void InitializeForm()
        {
            this.Text = "Dama Tahtası";
            this.Size = new Size(282, 305);
        }

        #region 1. Yol
        void PopulateButtons1() // 1. yol
        {
            Button button;
            int left;
            int top = 5;
            bool black;
            string[] characters = new string[8] {"A", "B", "C", "D", "E", "F", "G", "H"};
            string character;
            for (int i = 1; i <= 8; i++)
            {
                if (i % 2 == 0)
                    black = false;
                else
                    black = true;
                left = 5;
                character = characters[i - 1];
                for (int j = 1; j <= 8; j++)
                {
                    button = new Button();
                    button.Name = character + j;
                    button.Left = left;
                    button.Top = top;
                    button.Width = 32;
                    button.Height = 32;
                    button.BackColor = Color.White;
                    if (black)
                        button.BackColor = Color.Black;
                    button.Click += new EventHandler(button_Click);
                    this.Controls.Add(button); // this içinde bulunduğu class'tan türeyen objeyi refere eder yani ProgramExampleForm türündeki obje
                    left += 32;
                    black = !black;
                }
                top += 32;
            }
        }

        void button_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            MessageBox.Show(button.Name + " Clicked");
        }
        #endregion

        #region 2. Yol
        void PopulateButtons2()
        {
            Button[,] buttons = new Button[8, 8];
            int left;
            int top = 5;
            for (int i = 0; i <= buttons.GetUpperBound(0); i++)
            {
                left = 5;
                for (int j = 0; j <= buttons.GetUpperBound(1); j++)
                {
                    buttons[i, j] = new Button();
                    buttons[i, j].Width = 32;
                    buttons[i, j].Height = 32;
                    buttons[i, j].Left = left;
                    buttons[i, j].Top = top;
                    if ((i + j) % 2 == 0)
                        buttons[i, j].BackColor = Color.Black;
                    else
                        buttons[i, j].BackColor = Color.White;
                    this.Controls.Add(buttons[i, j]);
                    left += 32;
                }
                top += 32;
            }
        }
        #endregion
    }
}
