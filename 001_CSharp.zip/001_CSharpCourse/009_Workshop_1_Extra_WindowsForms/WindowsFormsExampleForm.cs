﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _009_Workshop_1_Extra_WindowsForms
{
    public partial class WindowsFormsExampleForm : Form
    {
        public WindowsFormsExampleForm()
        {
            InitializeComponent();
        }

        private void WindowsFormsExampleForm_Load(object sender, EventArgs e)
        {

        }
    }
}
