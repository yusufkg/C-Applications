﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _005_Arrays.Extras;

namespace _005_Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // Compile time errors: Derleme sırasında oluşan hatalar, syntax'dan olabilir, yanlış veri tipi atamalarından olabilir, atanmamış değerlerden olabilir
            // Run time errors: Çalışma sırasında oluşan hatalar, bir sayının 0'a bölümünden olabilir, bir infinite loop'tan dolayı memory'nin dolmasından olabilir, array'de olmyan bir index'e erişmekten olabilir*

            #region One-Dimensional Arrays
            string student1 = "Çağıl";
            string student2 = "Angel";
            string student3 = "Leo";

            string[] students = new string[3];
            students[0] = "Çağıl";
            students[1] = "Angel";
            students[2] = "Leo";

            int[] numbers = new[] { 1, 2, 3, 4 };
            decimal[] decimals = new decimal[5] { 1.1M, 2.2M, 3.3M, 4.4M, 5.5M };
            char[] characters = { 'A', 'B', 'C', 'D', 'E', 'F' };

            foreach (string student in students)
            {
                Console.WriteLine(student);
            }

            //for (int i = 0; i <= students.Length - 1; i++)
            for (int i = 0; i < students.Length; i++)
            {
                Console.WriteLine(students[i]);
            }

            // *array'de olmyan bir index'e erişmek
            //Console.WriteLine(characters[6]);
            #endregion

            #region Multi-Dimensional Arrays
            string[,] sehirler = new string[5, 3]
            {
                { "İstanbul", "İzmit", "Balıkesir" },
                { "Ankara", "Konya", "Kırıkkale" },
                { "Antalya", "Adana", "Mersin" },
                { "Rize", "Trabzon", "Samsun" },
                { "İzmir", "Muğla", "Manisa" }
            };
            for (int i = 0; i <= sehirler.GetUpperBound(0); i++) // sehirler.GetUpperBound(0): 4 (en son index), sehirler.GetUpperBound(1): 2 (en son index), sehirler.Length: 15
            {
                Console.Write((i + 1) + ". Bölge: ");
                for (int j = 0; j <= sehirler.GetUpperBound(1); j++)
                {
                    Console.Write(sehirler[i, j] + " ");
                }
                Console.WriteLine();
                Console.WriteLine("**********************************");
            }

            string[,] bolgelerVeSehirler1 = new string[3, 2];
            bolgelerVeSehirler1[0, 0] = "Marmara";
            bolgelerVeSehirler1[0, 1] = "İstanbul";
            bolgelerVeSehirler1[1, 0] = "Ege";
            bolgelerVeSehirler1[1, 1] = "İzmir";
            bolgelerVeSehirler1[2, 0] = "İç Anadolu";
            bolgelerVeSehirler1[2, 1] = "Ankara";
            string[,] bolgelerVeSehirler2 = new string[3, 2]
            {
                { "Marmara", "İstanbul" },
                { "Ege", "İzmir" },
                { "İç Anadolu", "Ankara" }
            };
            for (int i = 0; i <= bolgelerVeSehirler2.GetUpperBound(0); i++) 
            {
                Console.WriteLine("Bölge: " + bolgelerVeSehirler2[i, 0] + ", Şehir: " + bolgelerVeSehirler2[i, 1]);
            }
            #endregion

            #region Extras
            PlakalaraGoreSehirler.PlakalaraGoreSehirlerMethod();
            IliskiTesti.IliskiTestiMethod();
            #endregion

            Console.ReadLine();
        }
    }
}
